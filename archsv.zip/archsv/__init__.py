bl_info = {
    "name" : "ArchSV",
    "author" : "Node To Python",
    "version" : (1, 0, 0),
    "blender" : (4, 5, 0),
    "location" : "Node",
    "category" : "Node",
}

import bpy
import mathutils
import os

class ArchSV_PT_Panel(bpy.types.Panel):
    bl_label = "ArchSV"
    bl_idname = "ARCHSV_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = 'UI'
    bl_category = 'ArchSV'

    def draw(self, context):
        layout = self.layout
        layout.operator("object.archsv_add_curve_draw", text="Add Curve and Draw", icon='CURVE_BEZCURVE')
        layout.operator("node.archsv", text="Create ArchSV Node")

class ARCHSV_OT_AddCurveDraw(bpy.types.Operator):
    bl_idname = "object.archsv_add_curve_draw"
    bl_label = "Add Curve and Draw"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.active_object:
            bpy.ops.object.mode_set(mode='OBJECT')
    
        bpy.ops.curve.primitive_bezier_curve_add()
        curve_obj = context.active_object
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.curve.select_all(action='SELECT')
        bpy.ops.curve.delete(type='VERT')
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode='EDIT')
        
        # Switch to draw mode (sketching) with projection to surface
        bpy.ops.wm.tool_set_by_id(name="builtin.draw")
        bpy.context.scene.tool_settings.curve_paint_settings.depth_mode = 'SURFACE'

        bpy.ops.object.archsv_wait_for_curve_vertices('INVOKE_DEFAULT')

        self.report({'INFO'}, "Bezier curve added and ready for drawing.")
        return {'FINISHED'}

class ARCHSV_OT_WaitForCurveVertices(bpy.types.Operator):
    bl_idname = "object.archsv_wait_for_curve_vertices"
    bl_label = "Wait for Curve Vertices"
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    curve_obj = None

    def invoke(self, context, event=None):
        self.curve_obj = context.active_object
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.5, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'TIMER':
            if self.curve_obj and self.curve_obj.type == 'CURVE':
                for spline in self.curve_obj.data.splines:
                    if len(spline.bezier_points) > 0 or len(spline.points) > 0:
                        bpy.ops.object.mode_set(mode='OBJECT')
                        context.window_manager.event_timer_remove(self._timer)
                        self.report({'INFO'}, "Curve has vertices, exited edit mode.")
                        return {'FINISHED'}
        return {'PASS_THROUGH'}

class ArchSV(bpy.types.Operator):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    bl_idname = "node.archsv"
    bl_label = "ArchSV"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        #initialize nodegroup_001 node group
        def nodegroup_001_node_group():
            nodegroup_001 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "NodeGroup.001")

            nodegroup_001.color_tag = 'NONE'
            nodegroup_001.description = ""
            nodegroup_001.default_group_node_width = 140
            

            nodegroup_001.is_modifier = True

            #nodegroup_001 interface
            #Socket Output
            output_socket = nodegroup_001.interface.new_socket(name = "Output", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            output_socket.attribute_domain = 'POINT'
            output_socket.default_input = 'VALUE'
            output_socket.structure_type = 'AUTO'

            #Socket Target
            target_socket = nodegroup_001.interface.new_socket(name = "Target", in_out='INPUT', socket_type = 'NodeSocketGeometry')
            target_socket.attribute_domain = 'POINT'
            target_socket.default_input = 'VALUE'
            target_socket.structure_type = 'AUTO'

            #Socket Value
            value_socket = nodegroup_001.interface.new_socket(name = "Value", in_out='INPUT', socket_type = 'NodeSocketVector')
            value_socket.default_value = (0.0, 0.0, 0.0)
            value_socket.min_value = -3.4028234663852886e+38
            value_socket.max_value = 3.4028234663852886e+38
            value_socket.subtype = 'NONE'
            value_socket.attribute_domain = 'POINT'
            value_socket.default_input = 'VALUE'
            value_socket.structure_type = 'AUTO'

            #Socket Iterations
            iterations_socket = nodegroup_001.interface.new_socket(name = "Iterations", in_out='INPUT', socket_type = 'NodeSocketInt')
            iterations_socket.default_value = 35
            iterations_socket.min_value = 0
            iterations_socket.max_value = 2147483647
            iterations_socket.subtype = 'NONE'
            iterations_socket.attribute_domain = 'POINT'
            iterations_socket.default_input = 'VALUE'
            iterations_socket.structure_type = 'AUTO'

            #Socket Shphere resolution
            shphere_resolution_socket = nodegroup_001.interface.new_socket(name = "Shphere resolution", in_out='INPUT', socket_type = 'NodeSocketInt')
            shphere_resolution_socket.default_value = 6
            shphere_resolution_socket.min_value = 0
            shphere_resolution_socket.max_value = 6
            shphere_resolution_socket.subtype = 'NONE'
            shphere_resolution_socket.attribute_domain = 'POINT'
            shphere_resolution_socket.default_input = 'VALUE'
            shphere_resolution_socket.structure_type = 'AUTO'


            #initialize nodegroup_001 nodes
            #node Cube
            cube = nodegroup_001.nodes.new("GeometryNodeMeshCube")
            cube.name = "Cube"
            #Size
            cube.inputs[0].default_value = (1.0, 1.0, 1.0)
            #Vertices X
            cube.inputs[1].default_value = 2
            #Vertices Y
            cube.inputs[2].default_value = 2
            #Vertices Z
            cube.inputs[3].default_value = 2

            #node Transform Geometry
            transform_geometry = nodegroup_001.nodes.new("GeometryNodeTransform")
            transform_geometry.name = "Transform Geometry"
            transform_geometry.mode = 'COMPONENTS'
            #Rotation
            transform_geometry.inputs[2].default_value = (0.0, 0.0, 0.0)

            #node Attribute Statistic
            attribute_statistic = nodegroup_001.nodes.new("GeometryNodeAttributeStatistic")
            attribute_statistic.name = "Attribute Statistic"
            attribute_statistic.data_type = 'FLOAT_VECTOR'
            attribute_statistic.domain = 'POINT'
            #Selection
            attribute_statistic.inputs[1].default_value = True

            #node Position
            position = nodegroup_001.nodes.new("GeometryNodeInputPosition")
            position.name = "Position"

            #node Vector Math
            vector_math = nodegroup_001.nodes.new("ShaderNodeVectorMath")
            vector_math.name = "Vector Math"
            vector_math.operation = 'SUBTRACT'

            #node Vector Math.001
            vector_math_001 = nodegroup_001.nodes.new("ShaderNodeVectorMath")
            vector_math_001.name = "Vector Math.001"
            vector_math_001.operation = 'LENGTH'

            #node Combine XYZ
            combine_xyz = nodegroup_001.nodes.new("ShaderNodeCombineXYZ")
            combine_xyz.name = "Combine XYZ"

            #node Vector Math.002
            vector_math_002 = nodegroup_001.nodes.new("ShaderNodeVectorMath")
            vector_math_002.name = "Vector Math.002"
            vector_math_002.operation = 'MULTIPLY'

            #node Group Output
            group_output = nodegroup_001.nodes.new("NodeGroupOutput")
            group_output.name = "Group Output"
            group_output.is_active_output = True

            #node Subdivision Surface
            subdivision_surface = nodegroup_001.nodes.new("GeometryNodeSubdivisionSurface")
            subdivision_surface.name = "Subdivision Surface"
            subdivision_surface.boundary_smooth = 'ALL'
            subdivision_surface.uv_smooth = 'PRESERVE_BOUNDARIES'
            #Edge Crease
            subdivision_surface.inputs[2].default_value = 0.0
            #Vertex Crease
            subdivision_surface.inputs[3].default_value = 0.0
            #Limit Surface
            subdivision_surface.inputs[4].default_value = False

            #node Group Input
            group_input = nodegroup_001.nodes.new("NodeGroupInput")
            group_input.name = "Group Input"

            #node Repeat Input
            repeat_input = nodegroup_001.nodes.new("GeometryNodeRepeatInput")
            repeat_input.name = "Repeat Input"
            #node Set Position
            set_position = nodegroup_001.nodes.new("GeometryNodeSetPosition")
            set_position.name = "Set Position"
            #Selection
            set_position.inputs[1].default_value = True
            #Offset
            set_position.inputs[3].default_value = (0.0, 0.0, 0.0)

            #node Position.001
            position_001 = nodegroup_001.nodes.new("GeometryNodeInputPosition")
            position_001.name = "Position.001"

            #node Mix
            mix = nodegroup_001.nodes.new("ShaderNodeMix")
            mix.name = "Mix"
            mix.blend_type = 'MIX'
            mix.clamp_factor = True
            mix.clamp_result = False
            mix.data_type = 'VECTOR'
            mix.factor_mode = 'UNIFORM'
            #Factor_Float
            mix.inputs[0].default_value = 0.5

            #node Geometry Proximity
            geometry_proximity = nodegroup_001.nodes.new("GeometryNodeProximity")
            geometry_proximity.name = "Geometry Proximity"
            geometry_proximity.target_element = 'EDGES'
            #Group ID
            geometry_proximity.inputs[1].default_value = 0
            #Source Position
            geometry_proximity.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Sample Group ID
            geometry_proximity.inputs[3].default_value = 0

            #node Dual Mesh
            dual_mesh = nodegroup_001.nodes.new("GeometryNodeDualMesh")
            dual_mesh.name = "Dual Mesh"
            #Keep Boundaries
            dual_mesh.inputs[1].default_value = False

            #node Repeat Output
            repeat_output = nodegroup_001.nodes.new("GeometryNodeRepeatOutput")
            repeat_output.name = "Repeat Output"
            repeat_output.active_index = 0
            repeat_output.inspection_index = 0
            repeat_output.repeat_items.clear()
            # Create item "Geometry"
            repeat_output.repeat_items.new('GEOMETRY', "Geometry")

            #node Mesh to Volume
            mesh_to_volume = nodegroup_001.nodes.new("GeometryNodeMeshToVolume")
            mesh_to_volume.name = "Mesh to Volume"
            mesh_to_volume.resolution_mode = 'VOXEL_AMOUNT'
            #Density
            mesh_to_volume.inputs[1].default_value = 1.0
            #Voxel Amount
            mesh_to_volume.inputs[3].default_value = 128.0
            #Interior Band Width
            mesh_to_volume.inputs[4].default_value = 0.10000000149011612

            #node Volume to Mesh
            volume_to_mesh = nodegroup_001.nodes.new("GeometryNodeVolumeToMesh")
            volume_to_mesh.name = "Volume to Mesh"
            volume_to_mesh.resolution_mode = 'GRID'
            #Threshold
            volume_to_mesh.inputs[3].default_value = 0.10000000149011612
            #Adaptivity
            volume_to_mesh.inputs[4].default_value = 0.0

            #node Set Position.002
            set_position_002 = nodegroup_001.nodes.new("GeometryNodeSetPosition")
            set_position_002.name = "Set Position.002"
            #Selection
            set_position_002.inputs[1].default_value = True
            #Offset
            set_position_002.inputs[3].default_value = (0.0, 0.0, 0.0)

            #node Clamp
            clamp = nodegroup_001.nodes.new("ShaderNodeClamp")
            clamp.name = "Clamp"
            clamp.clamp_type = 'MINMAX'
            #Min
            clamp.inputs[1].default_value = 0.0
            #Max
            clamp.inputs[2].default_value = 11.0


            #Process zone input Repeat Input
            repeat_input.pair_with_output(repeat_output)





            #Set locations
            cube.location = (-1613.4854736328125, 775.5514526367188)
            transform_geometry.location = (-794.30908203125, 539.7982788085938)
            attribute_statistic.location = (-1762.3712158203125, 503.6514587402344)
            position.location = (-1764.99072265625, 168.2726287841797)
            vector_math.location = (-1583.2579345703125, 436.7962951660156)
            vector_math_001.location = (-1401.9366455078125, 416.6575622558594)
            combine_xyz.location = (-1199.530517578125, 413.609619140625)
            vector_math_002.location = (-1017.0291748046875, 372.63262939453125)
            group_output.location = (2596.6474609375, -27.902938842773438)
            subdivision_surface.location = (-626.1663818359375, 528.8346557617188)
            group_input.location = (-2011.2294921875, 4.220835208892822)
            repeat_input.location = (241.62359619140625, 438.03863525390625)
            set_position.location = (450.811767578125, 418.271728515625)
            position_001.location = (-81.18180847167969, 72.5733642578125)
            mix.location = (170.55540466308594, 181.67579650878906)
            geometry_proximity.location = (-81.74588012695312, 290.9593200683594)
            dual_mesh.location = (660.311767578125, 390.2865905761719)
            repeat_output.location = (844.30126953125, 458.767578125)
            mesh_to_volume.location = (1032.3992919921875, 382.8833312988281)
            volume_to_mesh.location = (1275.4102783203125, 333.3008117675781)
            set_position_002.location = (1473.3026123046875, 288.8031311035156)
            clamp.location = (-651.1663818359375, 528.8346557617188)

            #Set dimensions
            cube.width, cube.height = 140.0, 100.0
            transform_geometry.width, transform_geometry.height = 140.0, 100.0
            attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
            position.width, position.height = 140.0, 100.0
            vector_math.width, vector_math.height = 140.0, 100.0
            vector_math_001.width, vector_math_001.height = 140.0, 100.0
            combine_xyz.width, combine_xyz.height = 140.0, 100.0
            vector_math_002.width, vector_math_002.height = 140.0, 100.0
            group_output.width, group_output.height = 140.0, 100.0
            subdivision_surface.width, subdivision_surface.height = 150.0, 100.0
            group_input.width, group_input.height = 140.0, 100.0
            repeat_input.width, repeat_input.height = 140.0, 100.0
            set_position.width, set_position.height = 140.0, 100.0
            position_001.width, position_001.height = 140.0, 100.0
            mix.width, mix.height = 140.0, 100.0
            geometry_proximity.width, geometry_proximity.height = 140.0, 100.0
            dual_mesh.width, dual_mesh.height = 140.0, 100.0
            repeat_output.width, repeat_output.height = 140.0, 100.0
            mesh_to_volume.width, mesh_to_volume.height = 200.0, 100.0
            volume_to_mesh.width, volume_to_mesh.height = 170.0, 100.0
            set_position_002.width, set_position_002.height = 140.0, 100.0
            clamp.width, clamp.height = 140.0, 100.0

            #initialize nodegroup_001 links
            #cube.Mesh -> transform_geometry.Geometry
            nodegroup_001.links.new(cube.outputs[0], transform_geometry.inputs[0])
            #vector_math.Vector -> vector_math_001.Vector
            nodegroup_001.links.new(vector_math.outputs[0], vector_math_001.inputs[0])
            #position_001.Position -> mix.B
            nodegroup_001.links.new(position_001.outputs[0], mix.inputs[5])
            #position.Position -> attribute_statistic.Attribute
            nodegroup_001.links.new(position.outputs[0], attribute_statistic.inputs[2])
            #transform_geometry.Geometry -> subdivision_surface.Mesh
            nodegroup_001.links.new(transform_geometry.outputs[0], subdivision_surface.inputs[0])
            #mesh_to_volume.Volume -> volume_to_mesh.Volume
            nodegroup_001.links.new(mesh_to_volume.outputs[0], volume_to_mesh.inputs[0])
            #geometry_proximity.Position -> mix.A
            nodegroup_001.links.new(geometry_proximity.outputs[0], mix.inputs[4])
            #mix.Result -> set_position.Position
            nodegroup_001.links.new(mix.outputs[1], set_position.inputs[2])
            #attribute_statistic.Max -> vector_math.Vector
            nodegroup_001.links.new(attribute_statistic.outputs[4], vector_math.inputs[0])
            #attribute_statistic.Min -> vector_math.Vector
            nodegroup_001.links.new(attribute_statistic.outputs[3], vector_math.inputs[1])
            #group_input.Target -> attribute_statistic.Geometry
            nodegroup_001.links.new(group_input.outputs[0], attribute_statistic.inputs[0])
            #vector_math_001.Value -> combine_xyz.X
            nodegroup_001.links.new(vector_math_001.outputs[1], combine_xyz.inputs[0])
            #vector_math_001.Value -> combine_xyz.Y
            nodegroup_001.links.new(vector_math_001.outputs[1], combine_xyz.inputs[1])
            #vector_math_001.Value -> combine_xyz.Z
            nodegroup_001.links.new(vector_math_001.outputs[1], combine_xyz.inputs[2])
            #combine_xyz.Vector -> vector_math_002.Vector
            nodegroup_001.links.new(combine_xyz.outputs[0], vector_math_002.inputs[0])
            #vector_math_002.Vector -> transform_geometry.Scale
            nodegroup_001.links.new(vector_math_002.outputs[0], transform_geometry.inputs[3])
            #group_input.Value -> vector_math_002.Vector
            nodegroup_001.links.new(group_input.outputs[1], vector_math_002.inputs[1])
            #set_position.Geometry -> dual_mesh.Mesh
            nodegroup_001.links.new(set_position.outputs[0], dual_mesh.inputs[0])
            #group_input.Target -> geometry_proximity.Geometry
            nodegroup_001.links.new(group_input.outputs[0], geometry_proximity.inputs[0])
            #subdivision_surface.Mesh -> repeat_input.Geometry
            nodegroup_001.links.new(subdivision_surface.outputs[0], repeat_input.inputs[1])
            #group_input.Iterations -> repeat_input.Iterations
            nodegroup_001.links.new(group_input.outputs[2], repeat_input.inputs[0])
            #repeat_input.Geometry -> set_position.Geometry
            nodegroup_001.links.new(repeat_input.outputs[1], set_position.inputs[0])
            #dual_mesh.Dual Mesh -> repeat_output.Geometry
            nodegroup_001.links.new(dual_mesh.outputs[0], repeat_output.inputs[0])
            #volume_to_mesh.Mesh -> set_position_002.Geometry
            nodegroup_001.links.new(volume_to_mesh.outputs[0], set_position_002.inputs[0])
            #geometry_proximity.Position -> set_position_002.Position
            nodegroup_001.links.new(geometry_proximity.outputs[0], set_position_002.inputs[2])
            #repeat_output.Geometry -> mesh_to_volume.Mesh
            nodegroup_001.links.new(repeat_output.outputs[0], mesh_to_volume.inputs[0])
            #group_input.Shphere resolution -> subdivision_surface.Value
            nodegroup_001.links.new(group_input.outputs[3], subdivision_surface.inputs[1])
            #set_position_002.Geometry -> group_output.Output
            nodegroup_001.links.new(set_position_002.outputs[0], group_output.inputs[0])
            #attribute_statistic.Median -> transform_geometry.Translation
            nodegroup_001.links.new(attribute_statistic.outputs[1], transform_geometry.inputs[1])
            return nodegroup_001

        nodegroup_001 = nodegroup_001_node_group()

        #initialize nodegroup_003 node group
        def nodegroup_003_node_group():
            nodegroup_003 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "NodeGroup.003")

            nodegroup_003.color_tag = 'NONE'
            nodegroup_003.description = ""
            nodegroup_003.default_group_node_width = 140
            

            nodegroup_003.is_modifier = True

            #nodegroup_003 interface
            #Socket Geometry
            geometry_socket = nodegroup_003.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket.attribute_domain = 'POINT'
            geometry_socket.default_input = 'VALUE'
            geometry_socket.structure_type = 'AUTO'

            #Socket Geometry
            geometry_socket_1 = nodegroup_003.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_1.attribute_domain = 'POINT'
            geometry_socket_1.default_input = 'VALUE'
            geometry_socket_1.structure_type = 'AUTO'

            #Socket Voxel Amount
            voxel_amount_socket = nodegroup_003.interface.new_socket(name = "Voxel Amount", in_out='INPUT', socket_type = 'NodeSocketFloat')
            voxel_amount_socket.default_value = 384.0
            voxel_amount_socket.min_value = 0.0
            voxel_amount_socket.max_value = 3.4028234663852886e+38
            voxel_amount_socket.subtype = 'NONE'
            voxel_amount_socket.attribute_domain = 'POINT'
            voxel_amount_socket.default_input = 'VALUE'
            voxel_amount_socket.structure_type = 'AUTO'

            #Socket Level
            level_socket = nodegroup_003.interface.new_socket(name = "Level", in_out='INPUT', socket_type = 'NodeSocketInt')
            level_socket.default_value = 1
            level_socket.min_value = 0
            level_socket.max_value = 6
            level_socket.subtype = 'NONE'
            level_socket.attribute_domain = 'POINT'
            level_socket.default_input = 'VALUE'
            level_socket.structure_type = 'AUTO'


            #initialize nodegroup_003 nodes
            #node Geometry Proximity
            geometry_proximity_1 = nodegroup_003.nodes.new("GeometryNodeProximity")
            geometry_proximity_1.name = "Geometry Proximity"
            geometry_proximity_1.target_element = 'FACES'
            #Group ID
            geometry_proximity_1.inputs[1].default_value = 0
            #Source Position
            geometry_proximity_1.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Sample Group ID
            geometry_proximity_1.inputs[3].default_value = 0

            #node Mesh to Volume
            mesh_to_volume_1 = nodegroup_003.nodes.new("GeometryNodeMeshToVolume")
            mesh_to_volume_1.name = "Mesh to Volume"
            mesh_to_volume_1.resolution_mode = 'VOXEL_SIZE'
            #Density
            mesh_to_volume_1.inputs[1].default_value = 1000.0
            #Interior Band Width
            mesh_to_volume_1.inputs[4].default_value = 0.0

            #node Group Output
            group_output_1 = nodegroup_003.nodes.new("NodeGroupOutput")
            group_output_1.name = "Group Output"
            group_output_1.is_active_output = True

            #node Set Position
            set_position_1 = nodegroup_003.nodes.new("GeometryNodeSetPosition")
            set_position_1.name = "Set Position"
            #Selection
            set_position_1.inputs[1].default_value = True
            #Offset
            set_position_1.inputs[3].default_value = (0.0, 0.0, 0.0)

            #node Merge by Distance
            merge_by_distance = nodegroup_003.nodes.new("GeometryNodeMergeByDistance")
            merge_by_distance.name = "Merge by Distance"
            merge_by_distance.mode = 'ALL'
            #Selection
            merge_by_distance.inputs[1].default_value = True
            #Distance
            merge_by_distance.inputs[2].default_value = 0.05000000074505806

            #node Volume to Mesh
            volume_to_mesh_1 = nodegroup_003.nodes.new("GeometryNodeVolumeToMesh")
            volume_to_mesh_1.name = "Volume to Mesh"
            volume_to_mesh_1.resolution_mode = 'VOXEL_SIZE'
            #Threshold
            volume_to_mesh_1.inputs[3].default_value = 9.999999747378752e-06
            #Adaptivity
            volume_to_mesh_1.inputs[4].default_value = 0.0

            #node Group Input
            group_input_1 = nodegroup_003.nodes.new("NodeGroupInput")
            group_input_1.name = "Group Input"

            #node Math
            math = nodegroup_003.nodes.new("ShaderNodeMath")
            math.name = "Math"
            math.operation = 'DIVIDE'
            math.use_clamp = False
            #Value_001
            math.inputs[1].default_value = 500.0

            #node Subdivide Mesh
            subdivide_mesh = nodegroup_003.nodes.new("GeometryNodeSubdivideMesh")
            subdivide_mesh.name = "Subdivide Mesh"

            #node Clamp
            clamp_1 = nodegroup_003.nodes.new("ShaderNodeClamp")
            clamp_1.name = "Clamp"
            clamp_1.clamp_type = 'MINMAX'
            #Min
            clamp_1.inputs[1].default_value = 0.0
            #Max
            clamp_1.inputs[2].default_value = 11.0





            #Set locations
            geometry_proximity_1.location = (21.6322021484375, 130.75357055664062)
            mesh_to_volume_1.location = (-156.89674377441406, -203.3596649169922)
            group_output_1.location = (996.32763671875, -6.402298450469971)
            set_position_1.location = (543.8839111328125, -25.98114013671875)
            merge_by_distance.location = (-289.9984436035156, 217.69677734375)
            volume_to_mesh_1.location = (64.85460662841797, -101.37010955810547)
            group_input_1.location = (-652.0271606445312, -17.44196128845215)
            math.location = (-426.9098205566406, -65.9204330444336)
            subdivide_mesh.location = (316.2466125488281, -106.52388763427734)
            clamp_1.location = (291.2466125488281, -106.52388763427734)

            #Set dimensions
            geometry_proximity_1.width, geometry_proximity_1.height = 140.0, 100.0
            mesh_to_volume_1.width, mesh_to_volume_1.height = 200.0, 100.0
            group_output_1.width, group_output_1.height = 140.0, 100.0
            set_position_1.width, set_position_1.height = 140.0, 100.0
            merge_by_distance.width, merge_by_distance.height = 140.0, 100.0
            volume_to_mesh_1.width, volume_to_mesh_1.height = 170.0, 100.0
            group_input_1.width, group_input_1.height = 150.770263671875, 100.0
            math.width, math.height = 140.0, 100.0
            subdivide_mesh.width, subdivide_mesh.height = 140.0, 100.0
            clamp_1.width, clamp_1.height = 140.0, 100.0

            #initialize nodegroup_003 links
            #geometry_proximity_1.Position -> set_position_1.Position
            nodegroup_003.links.new(geometry_proximity_1.outputs[0], set_position_1.inputs[2])
            #group_input_1.Geometry -> merge_by_distance.Geometry
            nodegroup_003.links.new(group_input_1.outputs[0], merge_by_distance.inputs[0])
            #group_input_1.Voxel Amount -> volume_to_mesh_1.Voxel Amount
            nodegroup_003.links.new(group_input_1.outputs[1], volume_to_mesh_1.inputs[2])
            #mesh_to_volume_1.Volume -> volume_to_mesh_1.Volume
            nodegroup_003.links.new(mesh_to_volume_1.outputs[0], volume_to_mesh_1.inputs[0])
            #group_input_1.Geometry -> mesh_to_volume_1.Mesh
            nodegroup_003.links.new(group_input_1.outputs[0], mesh_to_volume_1.inputs[0])
            #group_input_1.Geometry -> geometry_proximity_1.Geometry
            nodegroup_003.links.new(group_input_1.outputs[0], geometry_proximity_1.inputs[0])
            #group_input_1.Voxel Amount -> math.Value
            nodegroup_003.links.new(group_input_1.outputs[1], math.inputs[0])
            #math.Value -> mesh_to_volume_1.Voxel Size
            nodegroup_003.links.new(math.outputs[0], mesh_to_volume_1.inputs[2])
            #math.Value -> volume_to_mesh_1.Voxel Size
            nodegroup_003.links.new(math.outputs[0], volume_to_mesh_1.inputs[1])
            #math.Value -> mesh_to_volume_1.Voxel Amount
            nodegroup_003.links.new(math.outputs[0], mesh_to_volume_1.inputs[3])
            #set_position_1.Geometry -> group_output_1.Geometry
            nodegroup_003.links.new(set_position_1.outputs[0], group_output_1.inputs[0])
            #volume_to_mesh_1.Mesh -> subdivide_mesh.Mesh
            nodegroup_003.links.new(volume_to_mesh_1.outputs[0], subdivide_mesh.inputs[0])
            #subdivide_mesh.Mesh -> set_position_1.Geometry
            nodegroup_003.links.new(subdivide_mesh.outputs[0], set_position_1.inputs[0])
            #group_input_1.Level -> subdivide_mesh.Value
            nodegroup_003.links.new(group_input_1.outputs[2], subdivide_mesh.inputs[1])
            return nodegroup_003

        nodegroup_003 = nodegroup_003_node_group()

        #initialize volumeapproximation node group
        def volumeapproximation_node_group():
            volumeapproximation = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "VolumeApproximation")

            volumeapproximation.color_tag = 'NONE'
            volumeapproximation.description = ""
            volumeapproximation.default_group_node_width = 140
            

            volumeapproximation.is_modifier = True

            #volumeapproximation interface
            #Socket SphereVolume
            spherevolume_socket = volumeapproximation.interface.new_socket(name = "SphereVolume", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            spherevolume_socket.attribute_domain = 'POINT'
            spherevolume_socket.default_input = 'VALUE'
            spherevolume_socket.structure_type = 'AUTO'

            #Socket VoxelVolume
            voxelvolume_socket = volumeapproximation.interface.new_socket(name = "VoxelVolume", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            voxelvolume_socket.attribute_domain = 'POINT'
            voxelvolume_socket.default_input = 'VALUE'
            voxelvolume_socket.structure_type = 'AUTO'

            #Socket Geometry
            geometry_socket_2 = volumeapproximation.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_2.attribute_domain = 'POINT'
            geometry_socket_2.default_input = 'VALUE'
            geometry_socket_2.structure_type = 'AUTO'

            #Socket View Sphere
            view_sphere_socket = volumeapproximation.interface.new_socket(name = "View Sphere", in_out='INPUT', socket_type = 'NodeSocketBool')
            view_sphere_socket.default_value = False
            view_sphere_socket.attribute_domain = 'POINT'
            view_sphere_socket.default_input = 'VALUE'
            view_sphere_socket.structure_type = 'AUTO'

            #Socket Sphere Size
            sphere_size_socket = volumeapproximation.interface.new_socket(name = "Sphere Size", in_out='INPUT', socket_type = 'NodeSocketVector')
            sphere_size_socket.default_value = (1.2000000476837158, 1.2000000476837158, 1.2000000476837158)
            sphere_size_socket.min_value = 4.0
            sphere_size_socket.max_value = 4.0
            sphere_size_socket.subtype = 'NONE'
            sphere_size_socket.attribute_domain = 'POINT'
            sphere_size_socket.default_input = 'VALUE'
            sphere_size_socket.structure_type = 'AUTO'

            #Socket Sphere Volume Iterations
            sphere_volume_iterations_socket = volumeapproximation.interface.new_socket(name = "Sphere Volume Iterations", in_out='INPUT', socket_type = 'NodeSocketFloat')
            sphere_volume_iterations_socket.default_value = 0.0
            sphere_volume_iterations_socket.min_value = -3.4028234663852886e+38
            sphere_volume_iterations_socket.max_value = 3.4028234663852886e+38
            sphere_volume_iterations_socket.subtype = 'NONE'
            sphere_volume_iterations_socket.attribute_domain = 'POINT'
            sphere_volume_iterations_socket.default_input = 'VALUE'
            sphere_volume_iterations_socket.structure_type = 'AUTO'

            #Socket Voxel Amount
            voxel_amount_socket_1 = volumeapproximation.interface.new_socket(name = "Voxel Amount", in_out='INPUT', socket_type = 'NodeSocketInt')
            voxel_amount_socket_1.default_value = 6
            voxel_amount_socket_1.min_value = 2
            voxel_amount_socket_1.max_value = 10
            voxel_amount_socket_1.subtype = 'NONE'
            voxel_amount_socket_1.attribute_domain = 'POINT'
            voxel_amount_socket_1.default_input = 'VALUE'
            voxel_amount_socket_1.structure_type = 'AUTO'


            #initialize volumeapproximation nodes
            #node Frame
            frame = volumeapproximation.nodes.new("NodeFrame")
            frame.label = "Switch between different volume calculations"
            frame.name = "Frame"
            frame.label_size = 20
            frame.shrink = True

            #node Group Output
            group_output_2 = volumeapproximation.nodes.new("NodeGroupOutput")
            group_output_2.name = "Group Output"
            group_output_2.is_active_output = True

            #node SphereVolumeCalculation
            spherevolumecalculation = volumeapproximation.nodes.new("GeometryNodeGroup")
            spherevolumecalculation.label = "SphereVolumeCalculation"
            spherevolumecalculation.name = "SphereVolumeCalculation"
            spherevolumecalculation.node_tree = nodegroup_001

            #node VoxelVolumeCalculation
            voxelvolumecalculation = volumeapproximation.nodes.new("GeometryNodeGroup")
            voxelvolumecalculation.label = "VoxelVolumeCalculation"
            voxelvolumecalculation.name = "VoxelVolumeCalculation"
            voxelvolumecalculation.node_tree = nodegroup_003

            #node Group Input
            group_input_2 = volumeapproximation.nodes.new("NodeGroupInput")
            group_input_2.name = "Group Input"




            #Set parents
            spherevolumecalculation.parent = frame
            voxelvolumecalculation.parent = frame

            #Set locations
            frame.location = (292.3333740234375, 110.16666412353516)
            group_output_2.location = (919.0576171875, -96.09332275390625)
            spherevolumecalculation.location = (29.1282958984375, -39.709136962890625)
            voxelvolumecalculation.location = (31.47021484375, -211.4884033203125)
            group_input_2.location = (-340.0, 0.0)

            #Set dimensions
            frame.width, frame.height = 200.6666259765625, 374.5
            group_output_2.width, group_output_2.height = 140.0, 100.0
            spherevolumecalculation.width, spherevolumecalculation.height = 140.0, 100.0
            voxelvolumecalculation.width, voxelvolumecalculation.height = 140.0, 100.0
            group_input_2.width, group_input_2.height = 140.0, 100.0

            #initialize volumeapproximation links
            #group_input_2.Geometry -> voxelvolumecalculation.Geometry
            volumeapproximation.links.new(group_input_2.outputs[0], voxelvolumecalculation.inputs[0])
            #group_input_2.Geometry -> spherevolumecalculation.Target
            volumeapproximation.links.new(group_input_2.outputs[0], spherevolumecalculation.inputs[0])
            #group_input_2.Sphere Size -> spherevolumecalculation.Value
            volumeapproximation.links.new(group_input_2.outputs[2], spherevolumecalculation.inputs[1])
            #group_input_2.Sphere Volume Iterations -> spherevolumecalculation.Iterations
            volumeapproximation.links.new(group_input_2.outputs[3], spherevolumecalculation.inputs[2])
            #spherevolumecalculation.Output -> group_output_2.SphereVolume
            volumeapproximation.links.new(spherevolumecalculation.outputs[0], group_output_2.inputs[0])
            #voxelvolumecalculation.Geometry -> group_output_2.VoxelVolume
            volumeapproximation.links.new(voxelvolumecalculation.outputs[0], group_output_2.inputs[1])
            #group_input_2.Sphere Volume Iterations -> voxelvolumecalculation.Voxel Amount
            volumeapproximation.links.new(group_input_2.outputs[3], voxelvolumecalculation.inputs[1])
            #group_input_2.Voxel Amount -> spherevolumecalculation.Shphere resolution
            volumeapproximation.links.new(group_input_2.outputs[4], spherevolumecalculation.inputs[3])
            #group_input_2.Voxel Amount -> voxelvolumecalculation.Level
            volumeapproximation.links.new(group_input_2.outputs[4], voxelvolumecalculation.inputs[2])
            return volumeapproximation

        volumeapproximation = volumeapproximation_node_group()

        #initialize seperate_by_xyz node group
        def seperate_by_xyz_node_group():
            seperate_by_xyz = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Seperate by XYZ")

            seperate_by_xyz.color_tag = 'NONE'
            seperate_by_xyz.description = ""
            seperate_by_xyz.default_group_node_width = 140
            


            #seperate_by_xyz interface
            #Socket Inverted
            inverted_socket = seperate_by_xyz.interface.new_socket(name = "Inverted", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            inverted_socket.attribute_domain = 'POINT'
            inverted_socket.default_input = 'VALUE'
            inverted_socket.structure_type = 'AUTO'

            #Socket Geometry
            geometry_socket_3 = seperate_by_xyz.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_3.attribute_domain = 'POINT'
            geometry_socket_3.default_input = 'VALUE'
            geometry_socket_3.structure_type = 'AUTO'

            #Socket Socket
            socket_socket = seperate_by_xyz.interface.new_socket(name = "Socket", in_out='INPUT', socket_type = 'NodeSocketGeometry')
            socket_socket.attribute_domain = 'POINT'
            socket_socket.default_input = 'VALUE'
            socket_socket.structure_type = 'AUTO'

            #Socket Attribute
            attribute_socket = seperate_by_xyz.interface.new_socket(name = "Attribute", in_out='INPUT', socket_type = 'NodeSocketGeometry')
            attribute_socket.attribute_domain = 'POINT'
            attribute_socket.hide_value = True
            attribute_socket.default_input = 'VALUE'
            attribute_socket.structure_type = 'AUTO'

            #Socket XY
            xy_socket = seperate_by_xyz.interface.new_socket(name = "XY", in_out='INPUT', socket_type = 'NodeSocketFloat')
            xy_socket.default_value = 0.5
            xy_socket.min_value = -10000.0
            xy_socket.max_value = 10000.0
            xy_socket.subtype = 'NONE'
            xy_socket.attribute_domain = 'POINT'
            xy_socket.default_input = 'VALUE'
            xy_socket.structure_type = 'AUTO'

            #Socket Z
            z_socket = seperate_by_xyz.interface.new_socket(name = "Z", in_out='INPUT', socket_type = 'NodeSocketFloat')
            z_socket.default_value = 0.5
            z_socket.min_value = -10000.0
            z_socket.max_value = 10000.0
            z_socket.subtype = 'NONE'
            z_socket.attribute_domain = 'POINT'
            z_socket.default_input = 'VALUE'
            z_socket.structure_type = 'AUTO'


            #initialize seperate_by_xyz nodes
            #node Group Output
            group_output_3 = seperate_by_xyz.nodes.new("NodeGroupOutput")
            group_output_3.name = "Group Output"
            group_output_3.is_active_output = True

            #node Group Input
            group_input_3 = seperate_by_xyz.nodes.new("NodeGroupInput")
            group_input_3.name = "Group Input"

            #node Attribute Statistic
            attribute_statistic_1 = seperate_by_xyz.nodes.new("GeometryNodeAttributeStatistic")
            attribute_statistic_1.name = "Attribute Statistic"
            attribute_statistic_1.data_type = 'FLOAT_VECTOR'
            attribute_statistic_1.domain = 'POINT'

            #node Separate XYZ
            separate_xyz = seperate_by_xyz.nodes.new("ShaderNodeSeparateXYZ")
            separate_xyz.name = "Separate XYZ"
            separate_xyz.hide = True

            #node Separate XYZ.001
            separate_xyz_001 = seperate_by_xyz.nodes.new("ShaderNodeSeparateXYZ")
            separate_xyz_001.name = "Separate XYZ.001"
            separate_xyz_001.hide = True

            #node Math
            math_1 = seperate_by_xyz.nodes.new("ShaderNodeMath")
            math_1.name = "Math"
            math_1.hide = True
            math_1.operation = 'ADD'
            math_1.use_clamp = False

            #node Math.001
            math_001 = seperate_by_xyz.nodes.new("ShaderNodeMath")
            math_001.name = "Math.001"
            math_001.hide = True
            math_001.operation = 'SUBTRACT'
            math_001.use_clamp = False

            #node Math.002
            math_002 = seperate_by_xyz.nodes.new("ShaderNodeMath")
            math_002.name = "Math.002"
            math_002.hide = True
            math_002.operation = 'ADD'
            math_002.use_clamp = False

            #node Math.003
            math_003 = seperate_by_xyz.nodes.new("ShaderNodeMath")
            math_003.name = "Math.003"
            math_003.hide = True
            math_003.operation = 'SUBTRACT'
            math_003.use_clamp = False

            #node Math.004
            math_004 = seperate_by_xyz.nodes.new("ShaderNodeMath")
            math_004.name = "Math.004"
            math_004.hide = True
            math_004.operation = 'MULTIPLY'
            math_004.use_clamp = False

            #node Math.005
            math_005 = seperate_by_xyz.nodes.new("ShaderNodeMath")
            math_005.name = "Math.005"
            math_005.hide = True
            math_005.operation = 'MULTIPLY'
            math_005.use_clamp = False

            #node Math.006
            math_006 = seperate_by_xyz.nodes.new("ShaderNodeMath")
            math_006.name = "Math.006"
            math_006.hide = True
            math_006.operation = 'MULTIPLY'
            math_006.use_clamp = False

            #node Position
            position_1 = seperate_by_xyz.nodes.new("GeometryNodeInputPosition")
            position_1.name = "Position"
            position_1.hide = True

            #node Separate XYZ.002
            separate_xyz_002 = seperate_by_xyz.nodes.new("ShaderNodeSeparateXYZ")
            separate_xyz_002.name = "Separate XYZ.002"
            separate_xyz_002.hide = True

            #node Math.007
            math_007 = seperate_by_xyz.nodes.new("ShaderNodeMath")
            math_007.name = "Math.007"
            math_007.hide = True
            math_007.operation = 'LESS_THAN'
            math_007.use_clamp = False

            #node Math.008
            math_008 = seperate_by_xyz.nodes.new("ShaderNodeMath")
            math_008.name = "Math.008"
            math_008.hide = True
            math_008.operation = 'GREATER_THAN'
            math_008.use_clamp = False

            #node Boolean Math
            boolean_math = seperate_by_xyz.nodes.new("FunctionNodeBooleanMath")
            boolean_math.name = "Boolean Math"
            boolean_math.hide = True
            boolean_math.operation = 'OR'

            #node Math.009
            math_009 = seperate_by_xyz.nodes.new("ShaderNodeMath")
            math_009.name = "Math.009"
            math_009.hide = True
            math_009.operation = 'LESS_THAN'
            math_009.use_clamp = False

            #node Math.010
            math_010 = seperate_by_xyz.nodes.new("ShaderNodeMath")
            math_010.name = "Math.010"
            math_010.hide = True
            math_010.operation = 'GREATER_THAN'
            math_010.use_clamp = False

            #node Boolean Math.001
            boolean_math_001 = seperate_by_xyz.nodes.new("FunctionNodeBooleanMath")
            boolean_math_001.name = "Boolean Math.001"
            boolean_math_001.hide = True
            boolean_math_001.operation = 'OR'

            #node Boolean Math.002
            boolean_math_002 = seperate_by_xyz.nodes.new("FunctionNodeBooleanMath")
            boolean_math_002.name = "Boolean Math.002"
            boolean_math_002.hide = True
            boolean_math_002.operation = 'OR'

            #node Math.011
            math_011 = seperate_by_xyz.nodes.new("ShaderNodeMath")
            math_011.name = "Math.011"
            math_011.hide = True
            math_011.operation = 'ADD'
            math_011.use_clamp = False

            #node Math.012
            math_012 = seperate_by_xyz.nodes.new("ShaderNodeMath")
            math_012.name = "Math.012"
            math_012.hide = True
            math_012.operation = 'SUBTRACT'
            math_012.use_clamp = False

            #node Math.013
            math_013 = seperate_by_xyz.nodes.new("ShaderNodeMath")
            math_013.name = "Math.013"
            math_013.hide = True
            math_013.operation = 'LESS_THAN'
            math_013.use_clamp = False

            #node Math.014
            math_014 = seperate_by_xyz.nodes.new("ShaderNodeMath")
            math_014.name = "Math.014"
            math_014.hide = True
            math_014.operation = 'GREATER_THAN'
            math_014.use_clamp = False

            #node Boolean Math.003
            boolean_math_003 = seperate_by_xyz.nodes.new("FunctionNodeBooleanMath")
            boolean_math_003.name = "Boolean Math.003"
            boolean_math_003.hide = True
            boolean_math_003.operation = 'OR'

            #node Boolean Math.004
            boolean_math_004 = seperate_by_xyz.nodes.new("FunctionNodeBooleanMath")
            boolean_math_004.name = "Boolean Math.004"
            boolean_math_004.hide = True
            boolean_math_004.operation = 'OR'

            #node Separate Geometry
            separate_geometry = seperate_by_xyz.nodes.new("GeometryNodeSeparateGeometry")
            separate_geometry.name = "Separate Geometry"
            separate_geometry.domain = 'FACE'

            #node Group Input.001
            group_input_001 = seperate_by_xyz.nodes.new("NodeGroupInput")
            group_input_001.name = "Group Input.001"

            #node Position.001
            position_001_1 = seperate_by_xyz.nodes.new("GeometryNodeInputPosition")
            position_001_1.name = "Position.001"

            #node Raycast
            raycast = seperate_by_xyz.nodes.new("GeometryNodeRaycast")
            raycast.name = "Raycast"
            raycast.data_type = 'FLOAT'
            raycast.mapping = 'INTERPOLATED'
            #Attribute
            raycast.inputs[1].default_value = 0.0
            #Source Position
            raycast.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Ray Direction
            raycast.inputs[3].default_value = (0.0, 0.0, -1.0)
            #Ray Length
            raycast.inputs[4].default_value = 0.20000000298023224





            #Set locations
            group_output_3.location = (1820.10888671875, 0.0)
            group_input_3.location = (-2435.820556640625, -48.31698226928711)
            attribute_statistic_1.location = (-1630.1090087890625, -7.1005859375)
            separate_xyz.location = (-1444.6546630859375, -30.464502334594727)
            separate_xyz_001.location = (-1447.003662109375, -155.1033935546875)
            math_1.location = (-910.458984375, 70.102294921875)
            math_001.location = (-911.6494140625, -57.723262786865234)
            math_002.location = (-914.3742065429688, 30.12378692626953)
            math_003.location = (-911.6494140625, -100.053466796875)
            math_004.location = (-1239.525390625, -106.34754943847656)
            math_005.location = (-1242.422607421875, -149.85415649414062)
            math_006.location = (-1240.9739990234375, -192.63565063476562)
            position_1.location = (-746.8046875, -244.73916625976562)
            separate_xyz_002.location = (-745.2809448242188, -211.70936584472656)
            math_007.location = (-249.4171142578125, 63.39513397216797)
            math_008.location = (-246.87744140625, 101.53231811523438)
            boolean_math.location = (29.67626953125, 97.56399536132812)
            math_009.location = (-254.4964599609375, -100.17059326171875)
            math_010.location = (-251.9566650390625, -62.03341293334961)
            boolean_math_001.location = (11.05224609375, -73.62914276123047)
            boolean_math_002.location = (302.3251953125, 71.44686889648438)
            math_011.location = (-915.2893676757812, -10.1893310546875)
            math_012.location = (-912.5646362304688, -140.3665771484375)
            math_013.location = (-256.3267822265625, -217.4451141357422)
            math_014.location = (-253.787109375, -179.3079376220703)
            boolean_math_003.location = (1.900390625, -194.56851196289062)
            boolean_math_004.location = (474.380126953125, 8.228561401367188)
            separate_geometry.location = (1273.5380859375, 164.16757202148438)
            group_input_001.location = (1030.9969482421875, 238.57826232910156)
            position_001_1.location = (-1625.1973876953125, -320.2380065917969)
            raycast.location = (-2047.8201904296875, -245.8093719482422)

            #Set dimensions
            group_output_3.width, group_output_3.height = 140.0, 100.0
            group_input_3.width, group_input_3.height = 140.0, 100.0
            attribute_statistic_1.width, attribute_statistic_1.height = 140.0, 100.0
            separate_xyz.width, separate_xyz.height = 140.0, 100.0
            separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
            math_1.width, math_1.height = 140.0, 100.0
            math_001.width, math_001.height = 140.0, 100.0
            math_002.width, math_002.height = 140.0, 100.0
            math_003.width, math_003.height = 140.0, 100.0
            math_004.width, math_004.height = 140.0, 100.0
            math_005.width, math_005.height = 140.0, 100.0
            math_006.width, math_006.height = 140.0, 100.0
            position_1.width, position_1.height = 140.0, 100.0
            separate_xyz_002.width, separate_xyz_002.height = 140.0, 100.0
            math_007.width, math_007.height = 140.0, 100.0
            math_008.width, math_008.height = 140.0, 100.0
            boolean_math.width, boolean_math.height = 140.0, 100.0
            math_009.width, math_009.height = 140.0, 100.0
            math_010.width, math_010.height = 140.0, 100.0
            boolean_math_001.width, boolean_math_001.height = 140.0, 100.0
            boolean_math_002.width, boolean_math_002.height = 140.0, 100.0
            math_011.width, math_011.height = 140.0, 100.0
            math_012.width, math_012.height = 140.0, 100.0
            math_013.width, math_013.height = 140.0, 100.0
            math_014.width, math_014.height = 140.0, 100.0
            boolean_math_003.width, boolean_math_003.height = 140.0, 100.0
            boolean_math_004.width, boolean_math_004.height = 129.9329376220703, 100.0
            separate_geometry.width, separate_geometry.height = 140.0, 100.0
            group_input_001.width, group_input_001.height = 140.0, 100.0
            position_001_1.width, position_001_1.height = 140.0, 100.0
            raycast.width, raycast.height = 150.0, 100.0

            #initialize seperate_by_xyz links
            #math_006.Value -> math_011.Value
            seperate_by_xyz.links.new(math_006.outputs[0], math_011.inputs[1])
            #separate_xyz.X -> math_001.Value
            seperate_by_xyz.links.new(separate_xyz.outputs[0], math_001.inputs[0])
            #separate_xyz_002.Y -> math_009.Value
            seperate_by_xyz.links.new(separate_xyz_002.outputs[1], math_009.inputs[0])
            #boolean_math.Boolean -> boolean_math_002.Boolean
            seperate_by_xyz.links.new(boolean_math.outputs[0], boolean_math_002.inputs[0])
            #separate_xyz_001.Y -> math_005.Value
            seperate_by_xyz.links.new(separate_xyz_001.outputs[1], math_005.inputs[0])
            #math_003.Value -> math_009.Value
            seperate_by_xyz.links.new(math_003.outputs[0], math_009.inputs[1])
            #math_013.Value -> boolean_math_003.Boolean
            seperate_by_xyz.links.new(math_013.outputs[0], boolean_math_003.inputs[1])
            #boolean_math_003.Boolean -> boolean_math_004.Boolean
            seperate_by_xyz.links.new(boolean_math_003.outputs[0], boolean_math_004.inputs[1])
            #separate_xyz_001.X -> math_004.Value
            seperate_by_xyz.links.new(separate_xyz_001.outputs[0], math_004.inputs[0])
            #separate_xyz_002.X -> math_008.Value
            seperate_by_xyz.links.new(separate_xyz_002.outputs[0], math_008.inputs[0])
            #math_004.Value -> math_001.Value
            seperate_by_xyz.links.new(math_004.outputs[0], math_001.inputs[1])
            #separate_xyz.X -> math_1.Value
            seperate_by_xyz.links.new(separate_xyz.outputs[0], math_1.inputs[0])
            #boolean_math_001.Boolean -> boolean_math_002.Boolean
            seperate_by_xyz.links.new(boolean_math_001.outputs[0], boolean_math_002.inputs[1])
            #math_006.Value -> math_012.Value
            seperate_by_xyz.links.new(math_006.outputs[0], math_012.inputs[1])
            #separate_xyz_002.Z -> math_013.Value
            seperate_by_xyz.links.new(separate_xyz_002.outputs[2], math_013.inputs[0])
            #separate_xyz.Z -> math_011.Value
            seperate_by_xyz.links.new(separate_xyz.outputs[2], math_011.inputs[0])
            #math_005.Value -> math_002.Value
            seperate_by_xyz.links.new(math_005.outputs[0], math_002.inputs[1])
            #math_001.Value -> math_007.Value
            seperate_by_xyz.links.new(math_001.outputs[0], math_007.inputs[1])
            #separate_xyz.Y -> math_002.Value
            seperate_by_xyz.links.new(separate_xyz.outputs[1], math_002.inputs[0])
            #math_014.Value -> boolean_math_003.Boolean
            seperate_by_xyz.links.new(math_014.outputs[0], boolean_math_003.inputs[0])
            #separate_xyz_001.Z -> math_006.Value
            seperate_by_xyz.links.new(separate_xyz_001.outputs[2], math_006.inputs[0])
            #separate_xyz_002.Z -> math_014.Value
            seperate_by_xyz.links.new(separate_xyz_002.outputs[2], math_014.inputs[0])
            #boolean_math_002.Boolean -> boolean_math_004.Boolean
            seperate_by_xyz.links.new(boolean_math_002.outputs[0], boolean_math_004.inputs[0])
            #math_002.Value -> math_010.Value
            seperate_by_xyz.links.new(math_002.outputs[0], math_010.inputs[1])
            #math_008.Value -> boolean_math.Boolean
            seperate_by_xyz.links.new(math_008.outputs[0], boolean_math.inputs[0])
            #math_1.Value -> math_008.Value
            seperate_by_xyz.links.new(math_1.outputs[0], math_008.inputs[1])
            #math_012.Value -> math_013.Value
            seperate_by_xyz.links.new(math_012.outputs[0], math_013.inputs[1])
            #math_007.Value -> boolean_math.Boolean
            seperate_by_xyz.links.new(math_007.outputs[0], boolean_math.inputs[1])
            #separate_xyz.Y -> math_003.Value
            seperate_by_xyz.links.new(separate_xyz.outputs[1], math_003.inputs[0])
            #position_1.Position -> separate_xyz_002.Vector
            seperate_by_xyz.links.new(position_1.outputs[0], separate_xyz_002.inputs[0])
            #math_011.Value -> math_014.Value
            seperate_by_xyz.links.new(math_011.outputs[0], math_014.inputs[1])
            #separate_xyz_002.Y -> math_010.Value
            seperate_by_xyz.links.new(separate_xyz_002.outputs[1], math_010.inputs[0])
            #separate_xyz_002.X -> math_007.Value
            seperate_by_xyz.links.new(separate_xyz_002.outputs[0], math_007.inputs[0])
            #math_009.Value -> boolean_math_001.Boolean
            seperate_by_xyz.links.new(math_009.outputs[0], boolean_math_001.inputs[1])
            #math_004.Value -> math_1.Value
            seperate_by_xyz.links.new(math_004.outputs[0], math_1.inputs[1])
            #math_005.Value -> math_003.Value
            seperate_by_xyz.links.new(math_005.outputs[0], math_003.inputs[1])
            #separate_xyz.Z -> math_012.Value
            seperate_by_xyz.links.new(separate_xyz.outputs[2], math_012.inputs[0])
            #math_010.Value -> boolean_math_001.Boolean
            seperate_by_xyz.links.new(math_010.outputs[0], boolean_math_001.inputs[0])
            #group_input_001.Socket -> separate_geometry.Geometry
            seperate_by_xyz.links.new(group_input_001.outputs[1], separate_geometry.inputs[0])
            #separate_geometry.Inverted -> group_output_3.Inverted
            seperate_by_xyz.links.new(separate_geometry.outputs[1], group_output_3.inputs[0])
            #group_input_3.Z -> math_006.Value
            seperate_by_xyz.links.new(group_input_3.outputs[4], math_006.inputs[1])
            #attribute_statistic_1.Mean -> separate_xyz.Vector
            seperate_by_xyz.links.new(attribute_statistic_1.outputs[0], separate_xyz.inputs[0])
            #boolean_math_004.Boolean -> separate_geometry.Selection
            seperate_by_xyz.links.new(boolean_math_004.outputs[0], separate_geometry.inputs[1])
            #attribute_statistic_1.Standard Deviation -> separate_xyz_001.Vector
            seperate_by_xyz.links.new(attribute_statistic_1.outputs[6], separate_xyz_001.inputs[0])
            #group_input_3.Geometry -> attribute_statistic_1.Geometry
            seperate_by_xyz.links.new(group_input_3.outputs[0], attribute_statistic_1.inputs[0])
            #position_001_1.Position -> attribute_statistic_1.Attribute
            seperate_by_xyz.links.new(position_001_1.outputs[0], attribute_statistic_1.inputs[2])
            #group_input_3.Attribute -> raycast.Target Geometry
            seperate_by_xyz.links.new(group_input_3.outputs[2], raycast.inputs[0])
            #raycast.Is Hit -> attribute_statistic_1.Selection
            seperate_by_xyz.links.new(raycast.outputs[0], attribute_statistic_1.inputs[1])
            #group_input_3.XY -> math_004.Value
            seperate_by_xyz.links.new(group_input_3.outputs[3], math_004.inputs[1])
            #group_input_3.XY -> math_005.Value
            seperate_by_xyz.links.new(group_input_3.outputs[3], math_005.inputs[1])
            return seperate_by_xyz

        seperate_by_xyz = seperate_by_xyz_node_group()

        #initialize edgepolyline node group
        def edgepolyline_node_group():
            edgepolyline = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "EdgePolyline")

            edgepolyline.color_tag = 'NONE'
            edgepolyline.description = ""
            edgepolyline.default_group_node_width = 140
            


            #edgepolyline interface
            #Socket Geometry
            geometry_socket_4 = edgepolyline.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_4.attribute_domain = 'POINT'
            geometry_socket_4.default_input = 'VALUE'
            geometry_socket_4.structure_type = 'AUTO'

            #Socket Geometry
            geometry_socket_5 = edgepolyline.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_5.attribute_domain = 'POINT'
            geometry_socket_5.default_input = 'VALUE'
            geometry_socket_5.structure_type = 'AUTO'

            #Socket Count
            count_socket = edgepolyline.interface.new_socket(name = "Count", in_out='INPUT', socket_type = 'NodeSocketInt')
            count_socket.default_value = 31
            count_socket.min_value = 1
            count_socket.max_value = 100000
            count_socket.subtype = 'NONE'
            count_socket.attribute_domain = 'POINT'
            count_socket.default_input = 'VALUE'
            count_socket.structure_type = 'AUTO'


            #initialize edgepolyline nodes
            #node Group Output
            group_output_4 = edgepolyline.nodes.new("NodeGroupOutput")
            group_output_4.name = "Group Output"
            group_output_4.is_active_output = True

            #node Group Input
            group_input_4 = edgepolyline.nodes.new("NodeGroupInput")
            group_input_4.name = "Group Input"

            #node Resample Curve
            resample_curve = edgepolyline.nodes.new("GeometryNodeResampleCurve")
            resample_curve.name = "Resample Curve"
            resample_curve.keep_last_segment = False
            resample_curve.mode = 'COUNT'
            #Selection
            resample_curve.inputs[1].default_value = True

            #node Curve to Mesh.001
            curve_to_mesh_001 = edgepolyline.nodes.new("GeometryNodeCurveToMesh")
            curve_to_mesh_001.name = "Curve to Mesh.001"
            #Scale
            curve_to_mesh_001.inputs[2].default_value = 1.0
            #Fill Caps
            curve_to_mesh_001.inputs[3].default_value = False

            #node Frame.001
            frame_001 = edgepolyline.nodes.new("NodeFrame")
            frame_001.label = "Separate Edge of Mesh"
            frame_001.name = "Frame.001"
            frame_001.label_size = 20
            frame_001.shrink = True

            #node Attribute Statistic
            attribute_statistic_2 = edgepolyline.nodes.new("GeometryNodeAttributeStatistic")
            attribute_statistic_2.name = "Attribute Statistic"
            attribute_statistic_2.data_type = 'FLOAT'
            attribute_statistic_2.domain = 'CURVE'
            #Selection
            attribute_statistic_2.inputs[1].default_value = True

            #node Spline Length
            spline_length = edgepolyline.nodes.new("GeometryNodeSplineLength")
            spline_length.name = "Spline Length"
            spline_length.hide = True

            #node Compare.002
            compare_002 = edgepolyline.nodes.new("FunctionNodeCompare")
            compare_002.name = "Compare.002"
            compare_002.data_type = 'FLOAT'
            compare_002.mode = 'ELEMENT'
            compare_002.operation = 'EQUAL'
            #Epsilon
            compare_002.inputs[12].default_value = 0.0

            #node Separate Geometry.001
            separate_geometry_001 = edgepolyline.nodes.new("GeometryNodeSeparateGeometry")
            separate_geometry_001.name = "Separate Geometry.001"
            separate_geometry_001.domain = 'CURVE'

            #node Set Spline Cyclic
            set_spline_cyclic = edgepolyline.nodes.new("GeometryNodeSetSplineCyclic")
            set_spline_cyclic.name = "Set Spline Cyclic"
            #Selection
            set_spline_cyclic.inputs[1].default_value = True
            #Cyclic
            set_spline_cyclic.inputs[2].default_value = True

            #node Mesh to Curve.001
            mesh_to_curve_001 = edgepolyline.nodes.new("GeometryNodeMeshToCurve")
            mesh_to_curve_001.name = "Mesh to Curve.001"
            mesh_to_curve_001.mode = 'EDGES'

            #node Compare.003
            compare_003 = edgepolyline.nodes.new("FunctionNodeCompare")
            compare_003.name = "Compare.003"
            compare_003.data_type = 'INT'
            compare_003.mode = 'ELEMENT'
            compare_003.operation = 'LESS_EQUAL'
            #B_INT
            compare_003.inputs[3].default_value = 1

            #node Edge Neighbors.002
            edge_neighbors_002 = edgepolyline.nodes.new("GeometryNodeInputMeshEdgeNeighbors")
            edge_neighbors_002.name = "Edge Neighbors.002"

            #node Viewer
            viewer = edgepolyline.nodes.new("GeometryNodeViewer")
            viewer.name = "Viewer"
            viewer.data_type = 'FLOAT'
            viewer.domain = 'AUTO'
            viewer.ui_shortcut = 0
            #Value
            viewer.inputs[1].default_value = 0.0




            #Set parents
            resample_curve.parent = frame_001
            curve_to_mesh_001.parent = frame_001
            attribute_statistic_2.parent = frame_001
            spline_length.parent = frame_001
            compare_002.parent = frame_001
            separate_geometry_001.parent = frame_001
            set_spline_cyclic.parent = frame_001
            mesh_to_curve_001.parent = frame_001
            compare_003.parent = frame_001
            edge_neighbors_002.parent = frame_001

            #Set locations
            group_output_4.location = (1107.48486328125, 0.0)
            group_input_4.location = (-1088.51513671875, 0.0)
            resample_curve.location = (223.572265625, -113.33848571777344)
            curve_to_mesh_001.location = (1405.604736328125, -73.5089111328125)
            frame_001.location = (-726.3333129882812, 224.4666748046875)
            attribute_statistic_2.location = (482.2303466796875, -348.99273681640625)
            spline_length.location = (479.4757080078125, -665.3538818359375)
            compare_002.location = (664.7210693359375, -324.56610107421875)
            separate_geometry_001.location = (845.6082763671875, -35.83502197265625)
            set_spline_cyclic.location = (1083.027099609375, -47.5302734375)
            mesh_to_curve_001.location = (35.7529296875, -90.05206298828125)
            compare_003.location = (29.172607421875, -200.09642028808594)
            edge_neighbors_002.location = (30.242431640625, -352.16156005859375)
            viewer.location = (-495.5530700683594, 361.1207580566406)

            #Set dimensions
            group_output_4.width, group_output_4.height = 140.0, 100.0
            group_input_4.width, group_input_4.height = 140.0, 100.0
            resample_curve.width, resample_curve.height = 140.0, 100.0
            curve_to_mesh_001.width, curve_to_mesh_001.height = 140.0, 100.0
            frame_001.width, frame_001.height = 1574.6666259765625, 718.300048828125
            attribute_statistic_2.width, attribute_statistic_2.height = 140.0, 100.0
            spline_length.width, spline_length.height = 140.0, 100.0
            compare_002.width, compare_002.height = 140.0, 100.0
            separate_geometry_001.width, separate_geometry_001.height = 140.0, 100.0
            set_spline_cyclic.width, set_spline_cyclic.height = 140.0, 100.0
            mesh_to_curve_001.width, mesh_to_curve_001.height = 140.0, 100.0
            compare_003.width, compare_003.height = 140.0, 100.0
            edge_neighbors_002.width, edge_neighbors_002.height = 140.0, 100.0
            viewer.width, viewer.height = 140.0, 100.0

            #initialize edgepolyline links
            #resample_curve.Curve -> separate_geometry_001.Geometry
            edgepolyline.links.new(resample_curve.outputs[0], separate_geometry_001.inputs[0])
            #compare_002.Result -> separate_geometry_001.Selection
            edgepolyline.links.new(compare_002.outputs[0], separate_geometry_001.inputs[1])
            #attribute_statistic_2.Max -> compare_002.B
            edgepolyline.links.new(attribute_statistic_2.outputs[4], compare_002.inputs[1])
            #resample_curve.Curve -> attribute_statistic_2.Geometry
            edgepolyline.links.new(resample_curve.outputs[0], attribute_statistic_2.inputs[0])
            #separate_geometry_001.Selection -> set_spline_cyclic.Geometry
            edgepolyline.links.new(separate_geometry_001.outputs[0], set_spline_cyclic.inputs[0])
            #set_spline_cyclic.Geometry -> curve_to_mesh_001.Curve
            edgepolyline.links.new(set_spline_cyclic.outputs[0], curve_to_mesh_001.inputs[0])
            #group_input_4.Count -> resample_curve.Count
            edgepolyline.links.new(group_input_4.outputs[1], resample_curve.inputs[2])
            #curve_to_mesh_001.Mesh -> group_output_4.Geometry
            edgepolyline.links.new(curve_to_mesh_001.outputs[0], group_output_4.inputs[0])
            #group_input_4.Geometry -> mesh_to_curve_001.Mesh
            edgepolyline.links.new(group_input_4.outputs[0], mesh_to_curve_001.inputs[0])
            #edge_neighbors_002.Face Count -> compare_003.A
            edgepolyline.links.new(edge_neighbors_002.outputs[0], compare_003.inputs[2])
            #compare_003.Result -> mesh_to_curve_001.Selection
            edgepolyline.links.new(compare_003.outputs[0], mesh_to_curve_001.inputs[1])
            #mesh_to_curve_001.Curve -> resample_curve.Curve
            edgepolyline.links.new(mesh_to_curve_001.outputs[0], resample_curve.inputs[0])
            #mesh_to_curve_001.Curve -> viewer.Geometry
            edgepolyline.links.new(mesh_to_curve_001.outputs[0], viewer.inputs[0])
            #attribute_statistic_2.Max -> compare_002.A
            edgepolyline.links.new(attribute_statistic_2.outputs[4], compare_002.inputs[2])
            #spline_length.Length -> attribute_statistic_2.Attribute
            edgepolyline.links.new(spline_length.outputs[0], attribute_statistic_2.inputs[2])
            #spline_length.Length -> compare_002.B
            edgepolyline.links.new(spline_length.outputs[0], compare_002.inputs[3])
            #spline_length.Length -> compare_002.A
            edgepolyline.links.new(spline_length.outputs[0], compare_002.inputs[0])
            return edgepolyline

        edgepolyline = edgepolyline_node_group()

        #initialize poly_creation node group
        def poly_creation_node_group():
            poly_creation = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Poly Creation")

            poly_creation.color_tag = 'NONE'
            poly_creation.description = ""
            poly_creation.default_group_node_width = 140
            


            #poly_creation interface
            #Socket Polygon
            polygon_socket = poly_creation.interface.new_socket(name = "Polygon", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            polygon_socket.attribute_domain = 'POINT'
            polygon_socket.default_input = 'VALUE'
            polygon_socket.structure_type = 'AUTO'

            #Socket Polyline
            polyline_socket = poly_creation.interface.new_socket(name = "Polyline", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            polyline_socket.attribute_domain = 'POINT'
            polyline_socket.default_input = 'VALUE'
            polyline_socket.structure_type = 'AUTO'

            #Socket Geometry
            geometry_socket_6 = poly_creation.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_6.attribute_domain = 'POINT'
            geometry_socket_6.default_input = 'VALUE'
            geometry_socket_6.structure_type = 'AUTO'

            #Socket Count
            count_socket_1 = poly_creation.interface.new_socket(name = "Count", in_out='INPUT', socket_type = 'NodeSocketInt')
            count_socket_1.default_value = 31
            count_socket_1.min_value = 1
            count_socket_1.max_value = 100000
            count_socket_1.subtype = 'NONE'
            count_socket_1.attribute_domain = 'POINT'
            count_socket_1.default_input = 'VALUE'
            count_socket_1.structure_type = 'AUTO'


            #initialize poly_creation nodes
            #node Group Output
            group_output_5 = poly_creation.nodes.new("NodeGroupOutput")
            group_output_5.name = "Group Output"
            group_output_5.is_active_output = True

            #node Group Input
            group_input_5 = poly_creation.nodes.new("NodeGroupInput")
            group_input_5.name = "Group Input"

            #node Attribute Statistic.001
            attribute_statistic_001 = poly_creation.nodes.new("GeometryNodeAttributeStatistic")
            attribute_statistic_001.name = "Attribute Statistic.001"
            attribute_statistic_001.data_type = 'FLOAT'
            attribute_statistic_001.domain = 'POINT'
            #Selection
            attribute_statistic_001.inputs[1].default_value = True

            #node Sample Index
            sample_index = poly_creation.nodes.new("GeometryNodeSampleIndex")
            sample_index.name = "Sample Index"
            sample_index.clamp = True
            sample_index.data_type = 'FLOAT_VECTOR'
            sample_index.domain = 'POINT'

            #node Position.002
            position_002 = poly_creation.nodes.new("GeometryNodeInputPosition")
            position_002.name = "Position.002"

            #node Index
            index = poly_creation.nodes.new("GeometryNodeInputIndex")
            index.name = "Index"

            #node Math.015
            math_015 = poly_creation.nodes.new("ShaderNodeMath")
            math_015.name = "Math.015"
            math_015.operation = 'ADD'
            math_015.use_clamp = False
            #Value_001
            math_015.inputs[1].default_value = 1.0

            #node Mesh Circle
            mesh_circle = poly_creation.nodes.new("GeometryNodeMeshCircle")
            mesh_circle.name = "Mesh Circle"
            mesh_circle.fill_type = 'NGON'
            #Radius
            mesh_circle.inputs[1].default_value = 1.0

            #node Set Position.001
            set_position_001 = poly_creation.nodes.new("GeometryNodeSetPosition")
            set_position_001.name = "Set Position.001"
            #Selection
            set_position_001.inputs[1].default_value = True
            #Offset
            set_position_001.inputs[3].default_value = (0.0, 0.0, 0.0)

            #node Triangulate
            triangulate = poly_creation.nodes.new("GeometryNodeTriangulate")
            triangulate.name = "Triangulate"
            triangulate.ngon_method = 'BEAUTY'
            triangulate.quad_method = 'BEAUTY'
            #Selection
            triangulate.inputs[1].default_value = True

            #node Frame
            frame_1 = poly_creation.nodes.new("NodeFrame")
            frame_1.label = "Fill Curve"
            frame_1.name = "Frame"
            frame_1.label_size = 20
            frame_1.shrink = True

            #node Group.001
            group_001 = poly_creation.nodes.new("GeometryNodeGroup")
            group_001.name = "Group.001"
            group_001.node_tree = edgepolyline




            #Set parents
            attribute_statistic_001.parent = frame_1
            sample_index.parent = frame_1
            position_002.parent = frame_1
            index.parent = frame_1
            math_015.parent = frame_1
            mesh_circle.parent = frame_1
            set_position_001.parent = frame_1
            triangulate.parent = frame_1

            #Set locations
            group_output_5.location = (220.6656494140625, 93.11943817138672)
            group_input_5.location = (-2051.769775390625, 9.350010871887207)
            attribute_statistic_001.location = (274.95721435546875, -35.46807861328125)
            sample_index.location = (271.87103271484375, -417.12982177734375)
            position_002.location = (43.1112060546875, -523.2941284179688)
            index.location = (29.2401123046875, -600.0970458984375)
            math_015.location = (437.17425537109375, -92.41738891601562)
            mesh_circle.location = (635.99853515625, -76.68667602539062)
            set_position_001.location = (807.0790405273438, -88.71603393554688)
            triangulate.location = (997.27392578125, -113.80743408203125)
            frame_1.location = (-1247.0, 391.8000183105469)
            group_001.location = (-1624.6370849609375, 56.9328727722168)

            #Set dimensions
            group_output_5.width, group_output_5.height = 140.0, 100.0
            group_input_5.width, group_input_5.height = 140.0, 100.0
            attribute_statistic_001.width, attribute_statistic_001.height = 140.0, 100.0
            sample_index.width, sample_index.height = 140.0, 100.0
            position_002.width, position_002.height = 140.0, 100.0
            index.width, index.height = 140.0, 100.0
            math_015.width, math_015.height = 140.0, 100.0
            mesh_circle.width, mesh_circle.height = 140.0, 100.0
            set_position_001.width, set_position_001.height = 140.0, 100.0
            triangulate.width, triangulate.height = 140.0, 100.0
            frame_1.width, frame_1.height = 1166.0, 676.800048828125
            group_001.width, group_001.height = 140.0, 100.0

            #initialize poly_creation links
            #attribute_statistic_001.Max -> math_015.Value
            poly_creation.links.new(attribute_statistic_001.outputs[4], math_015.inputs[0])
            #index.Index -> attribute_statistic_001.Attribute
            poly_creation.links.new(index.outputs[0], attribute_statistic_001.inputs[2])
            #index.Index -> sample_index.Index
            poly_creation.links.new(index.outputs[0], sample_index.inputs[2])
            #sample_index.Value -> set_position_001.Position
            poly_creation.links.new(sample_index.outputs[0], set_position_001.inputs[2])
            #math_015.Value -> mesh_circle.Vertices
            poly_creation.links.new(math_015.outputs[0], mesh_circle.inputs[0])
            #mesh_circle.Mesh -> set_position_001.Geometry
            poly_creation.links.new(mesh_circle.outputs[0], set_position_001.inputs[0])
            #position_002.Position -> sample_index.Value
            poly_creation.links.new(position_002.outputs[0], sample_index.inputs[1])
            #set_position_001.Geometry -> triangulate.Mesh
            poly_creation.links.new(set_position_001.outputs[0], triangulate.inputs[0])
            #group_001.Geometry -> attribute_statistic_001.Geometry
            poly_creation.links.new(group_001.outputs[0], attribute_statistic_001.inputs[0])
            #group_input_5.Geometry -> group_001.Geometry
            poly_creation.links.new(group_input_5.outputs[0], group_001.inputs[0])
            #group_input_5.Count -> group_001.Count
            poly_creation.links.new(group_input_5.outputs[1], group_001.inputs[1])
            #group_001.Geometry -> sample_index.Geometry
            poly_creation.links.new(group_001.outputs[0], sample_index.inputs[0])
            #group_001.Geometry -> group_output_5.Polyline
            poly_creation.links.new(group_001.outputs[0], group_output_5.inputs[1])
            #triangulate.Mesh -> group_output_5.Polygon
            poly_creation.links.new(triangulate.outputs[0], group_output_5.inputs[0])
            return poly_creation

        poly_creation = poly_creation_node_group()

        #initialize smoothing node group
        def smoothing_node_group():
            smoothing = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Smoothing")

            smoothing.color_tag = 'NONE'
            smoothing.description = ""
            smoothing.default_group_node_width = 140
            


            #smoothing interface
            #Socket Geometry
            geometry_socket_7 = smoothing.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_7.attribute_domain = 'POINT'
            geometry_socket_7.default_input = 'VALUE'
            geometry_socket_7.structure_type = 'AUTO'

            #Socket Geometry
            geometry_socket_8 = smoothing.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_8.attribute_domain = 'POINT'
            geometry_socket_8.default_input = 'VALUE'
            geometry_socket_8.structure_type = 'AUTO'

            #Socket Iterations
            iterations_socket_1 = smoothing.interface.new_socket(name = "Iterations", in_out='INPUT', socket_type = 'NodeSocketInt')
            iterations_socket_1.default_value = 156
            iterations_socket_1.min_value = 0
            iterations_socket_1.max_value = 2147483647
            iterations_socket_1.subtype = 'NONE'
            iterations_socket_1.attribute_domain = 'POINT'
            iterations_socket_1.default_input = 'VALUE'
            iterations_socket_1.structure_type = 'AUTO'


            #initialize smoothing nodes
            #node Group Output
            group_output_6 = smoothing.nodes.new("NodeGroupOutput")
            group_output_6.name = "Group Output"
            group_output_6.is_active_output = True

            #node Group Input
            group_input_6 = smoothing.nodes.new("NodeGroupInput")
            group_input_6.name = "Group Input"

            #node Set Position.002
            set_position_002_1 = smoothing.nodes.new("GeometryNodeSetPosition")
            set_position_002_1.name = "Set Position.002"
            #Offset
            set_position_002_1.inputs[3].default_value = (0.0, 0.0, 0.0)

            #node Edge Vertices.001
            edge_vertices_001 = smoothing.nodes.new("GeometryNodeInputMeshEdgeVertices")
            edge_vertices_001.name = "Edge Vertices.001"
            edge_vertices_001.hide = True

            #node Vector Math.002
            vector_math_002_1 = smoothing.nodes.new("ShaderNodeVectorMath")
            vector_math_002_1.name = "Vector Math.002"
            vector_math_002_1.hide = True
            vector_math_002_1.operation = 'ADD'

            #node Separate XYZ.005
            separate_xyz_005 = smoothing.nodes.new("ShaderNodeSeparateXYZ")
            separate_xyz_005.name = "Separate XYZ.005"
            separate_xyz_005.hide = True

            #node Combine XYZ.001
            combine_xyz_001 = smoothing.nodes.new("ShaderNodeCombineXYZ")
            combine_xyz_001.name = "Combine XYZ.001"
            combine_xyz_001.hide = True

            #node Position.003
            position_003 = smoothing.nodes.new("GeometryNodeInputPosition")
            position_003.name = "Position.003"

            #node Separate XYZ.006
            separate_xyz_006 = smoothing.nodes.new("ShaderNodeSeparateXYZ")
            separate_xyz_006.name = "Separate XYZ.006"
            separate_xyz_006.hide = True

            #node Repeat Input.001
            repeat_input_001 = smoothing.nodes.new("GeometryNodeRepeatInput")
            repeat_input_001.name = "Repeat Input.001"
            #node Repeat Output.001
            repeat_output_001 = smoothing.nodes.new("GeometryNodeRepeatOutput")
            repeat_output_001.name = "Repeat Output.001"
            repeat_output_001.active_index = 0
            repeat_output_001.inspection_index = 0
            repeat_output_001.repeat_items.clear()
            # Create item "Geometry"
            repeat_output_001.repeat_items.new('GEOMETRY', "Geometry")

            #node Vector Math.003
            vector_math_003 = smoothing.nodes.new("ShaderNodeVectorMath")
            vector_math_003.name = "Vector Math.003"
            vector_math_003.hide = True
            vector_math_003.operation = 'SCALE'
            #Scale
            vector_math_003.inputs[3].default_value = 0.5

            #node Compare.002
            compare_002_1 = smoothing.nodes.new("FunctionNodeCompare")
            compare_002_1.name = "Compare.002"
            compare_002_1.data_type = 'INT'
            compare_002_1.mode = 'ELEMENT'
            compare_002_1.operation = 'EQUAL'
            #B_INT
            compare_002_1.inputs[3].default_value = 2

            #node Edge Neighbors.002
            edge_neighbors_002_1 = smoothing.nodes.new("GeometryNodeInputMeshEdgeNeighbors")
            edge_neighbors_002_1.name = "Edge Neighbors.002"


            #Process zone input Repeat Input.001
            repeat_input_001.pair_with_output(repeat_output_001)





            #Set locations
            group_output_6.location = (587.704833984375, 0.0)
            group_input_6.location = (-597.70458984375, 0.0)
            set_position_002_1.location = (79.939208984375, 180.40789794921875)
            edge_vertices_001.location = (-336.3466796875, -267.408935546875)
            vector_math_002_1.location = (-337.2119140625, -232.10377502441406)
            separate_xyz_005.location = (-335.564208984375, -161.048828125)
            combine_xyz_001.location = (-132.4443359375, -109.755615234375)
            position_003.location = (-336.1085205078125, -50.01417922973633)
            separate_xyz_006.location = (-336.054443359375, -107.40365600585938)
            repeat_input_001.location = (-191.265869140625, 164.97784423828125)
            repeat_output_001.location = (397.704833984375, 222.20916748046875)
            vector_math_003.location = (-336.458740234375, -197.05958557128906)
            compare_002_1.location = (-151.9776153564453, 411.2741394042969)
            edge_neighbors_002_1.location = (-318.5020446777344, 391.910888671875)

            #Set dimensions
            group_output_6.width, group_output_6.height = 140.0, 100.0
            group_input_6.width, group_input_6.height = 140.0, 100.0
            set_position_002_1.width, set_position_002_1.height = 140.0, 100.0
            edge_vertices_001.width, edge_vertices_001.height = 140.0, 100.0
            vector_math_002_1.width, vector_math_002_1.height = 140.0, 100.0
            separate_xyz_005.width, separate_xyz_005.height = 140.0, 100.0
            combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
            position_003.width, position_003.height = 140.0, 100.0
            separate_xyz_006.width, separate_xyz_006.height = 140.0, 100.0
            repeat_input_001.width, repeat_input_001.height = 140.0, 100.0
            repeat_output_001.width, repeat_output_001.height = 140.0, 100.0
            vector_math_003.width, vector_math_003.height = 140.0, 100.0
            compare_002_1.width, compare_002_1.height = 140.0, 100.0
            edge_neighbors_002_1.width, edge_neighbors_002_1.height = 140.0, 100.0

            #initialize smoothing links
            #position_003.Position -> separate_xyz_006.Vector
            smoothing.links.new(position_003.outputs[0], separate_xyz_006.inputs[0])
            #edge_vertices_001.Position 1 -> vector_math_002_1.Vector
            smoothing.links.new(edge_vertices_001.outputs[2], vector_math_002_1.inputs[0])
            #separate_xyz_006.X -> combine_xyz_001.X
            smoothing.links.new(separate_xyz_006.outputs[0], combine_xyz_001.inputs[0])
            #repeat_input_001.Geometry -> set_position_002_1.Geometry
            smoothing.links.new(repeat_input_001.outputs[1], set_position_002_1.inputs[0])
            #combine_xyz_001.Vector -> set_position_002_1.Position
            smoothing.links.new(combine_xyz_001.outputs[0], set_position_002_1.inputs[2])
            #edge_vertices_001.Position 2 -> vector_math_002_1.Vector
            smoothing.links.new(edge_vertices_001.outputs[3], vector_math_002_1.inputs[1])
            #vector_math_003.Vector -> separate_xyz_005.Vector
            smoothing.links.new(vector_math_003.outputs[0], separate_xyz_005.inputs[0])
            #edge_neighbors_002_1.Face Count -> compare_002_1.A
            smoothing.links.new(edge_neighbors_002_1.outputs[0], compare_002_1.inputs[2])
            #separate_xyz_005.Z -> combine_xyz_001.Z
            smoothing.links.new(separate_xyz_005.outputs[2], combine_xyz_001.inputs[2])
            #compare_002_1.Result -> set_position_002_1.Selection
            smoothing.links.new(compare_002_1.outputs[0], set_position_002_1.inputs[1])
            #separate_xyz_006.Y -> combine_xyz_001.Y
            smoothing.links.new(separate_xyz_006.outputs[1], combine_xyz_001.inputs[1])
            #set_position_002_1.Geometry -> repeat_output_001.Geometry
            smoothing.links.new(set_position_002_1.outputs[0], repeat_output_001.inputs[0])
            #vector_math_002_1.Vector -> vector_math_003.Vector
            smoothing.links.new(vector_math_002_1.outputs[0], vector_math_003.inputs[0])
            #group_input_6.Geometry -> repeat_input_001.Geometry
            smoothing.links.new(group_input_6.outputs[0], repeat_input_001.inputs[1])
            #repeat_output_001.Geometry -> group_output_6.Geometry
            smoothing.links.new(repeat_output_001.outputs[0], group_output_6.inputs[0])
            #group_input_6.Iterations -> repeat_input_001.Iterations
            smoothing.links.new(group_input_6.outputs[1], repeat_input_001.inputs[0])
            return smoothing

        smoothing = smoothing_node_group()

        #initialize slope_grouping node group
        def slope_grouping_node_group():
            slope_grouping = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Slope Grouping")

            slope_grouping.color_tag = 'NONE'
            slope_grouping.description = ""
            slope_grouping.default_group_node_width = 140
            

            slope_grouping.is_modifier = True

            #slope_grouping interface
            #Socket Geometry
            geometry_socket_9 = slope_grouping.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_9.attribute_domain = 'POINT'
            geometry_socket_9.default_input = 'VALUE'
            geometry_socket_9.structure_type = 'AUTO'

            #Socket Geometry
            geometry_socket_10 = slope_grouping.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_10.attribute_domain = 'POINT'
            geometry_socket_10.default_input = 'VALUE'
            geometry_socket_10.structure_type = 'AUTO'

            #Socket Base/Top
            base_top_socket = slope_grouping.interface.new_socket(name = "Base/Top", in_out='INPUT', socket_type = 'NodeSocketBool')
            base_top_socket.default_value = False
            base_top_socket.attribute_domain = 'POINT'
            base_top_socket.default_input = 'VALUE'
            base_top_socket.structure_type = 'AUTO'

            #Socket Nor Var
            nor_var_socket = slope_grouping.interface.new_socket(name = "Nor Var", in_out='INPUT', socket_type = 'NodeSocketFloat')
            nor_var_socket.default_value = 0.30000001192092896
            nor_var_socket.min_value = -10000.0
            nor_var_socket.max_value = 10000.0
            nor_var_socket.subtype = 'NONE'
            nor_var_socket.attribute_domain = 'POINT'
            nor_var_socket.default_input = 'VALUE'
            nor_var_socket.structure_type = 'AUTO'

            #Socket Iterations
            iterations_socket_2 = slope_grouping.interface.new_socket(name = "Iterations", in_out='INPUT', socket_type = 'NodeSocketInt')
            iterations_socket_2.default_value = 20
            iterations_socket_2.min_value = 0
            iterations_socket_2.max_value = 2147483647
            iterations_socket_2.subtype = 'NONE'
            iterations_socket_2.attribute_domain = 'POINT'
            iterations_socket_2.default_input = 'VALUE'
            iterations_socket_2.structure_type = 'AUTO'


            #initialize slope_grouping nodes
            #node Group Input
            group_input_7 = slope_grouping.nodes.new("NodeGroupInput")
            group_input_7.name = "Group Input"
            group_input_7.outputs[1].hide = True

            #node Group Output
            group_output_7 = slope_grouping.nodes.new("NodeGroupOutput")
            group_output_7.name = "Group Output"
            group_output_7.is_active_output = True

            #node Group
            group = slope_grouping.nodes.new("GeometryNodeGroup")
            group.name = "Group"
            group.node_tree = smoothing

            #node Normal.002
            normal_002 = slope_grouping.nodes.new("GeometryNodeInputNormal")
            normal_002.name = "Normal.002"
            normal_002.legacy_corner_normals = True

            #node Vector Math.001
            vector_math_001_1 = slope_grouping.nodes.new("ShaderNodeVectorMath")
            vector_math_001_1.name = "Vector Math.001"
            vector_math_001_1.operation = 'DOT_PRODUCT'
            #Vector
            vector_math_001_1.inputs[0].default_value = (0.0, 0.0, 1.0)

            #node Math.006
            math_006_1 = slope_grouping.nodes.new("ShaderNodeMath")
            math_006_1.name = "Math.006"
            math_006_1.operation = 'ARCCOSINE'
            math_006_1.use_clamp = False

            #node Compare.006
            compare_006 = slope_grouping.nodes.new("FunctionNodeCompare")
            compare_006.name = "Compare.006"
            compare_006.data_type = 'FLOAT'
            compare_006.mode = 'ELEMENT'
            compare_006.operation = 'LESS_THAN'

            #node Delete Geometry
            delete_geometry = slope_grouping.nodes.new("GeometryNodeDeleteGeometry")
            delete_geometry.name = "Delete Geometry"
            delete_geometry.domain = 'POINT'
            delete_geometry.mode = 'ALL'

            #node Boolean Math
            boolean_math_1 = slope_grouping.nodes.new("FunctionNodeBooleanMath")
            boolean_math_1.name = "Boolean Math"
            boolean_math_1.operation = 'NOT'

            #node Switch
            switch = slope_grouping.nodes.new("GeometryNodeSwitch")
            switch.name = "Switch"
            switch.input_type = 'BOOLEAN'

            #node Group Input.001
            group_input_001_1 = slope_grouping.nodes.new("NodeGroupInput")
            group_input_001_1.name = "Group Input.001"
            group_input_001_1.outputs[0].hide = True
            group_input_001_1.outputs[2].hide = True
            group_input_001_1.outputs[3].hide = True
            group_input_001_1.outputs[4].hide = True





            #Set locations
            group_input_7.location = (204.3592987060547, -181.8707733154297)
            group_output_7.location = (1857.68994140625, 283.29705810546875)
            group.location = (742.7443237304688, 212.7920379638672)
            normal_002.location = (213.9716033935547, -612.05859375)
            vector_math_001_1.location = (218.01222229003906, -425.3138732910156)
            math_006_1.location = (381.5095520019531, -423.9817810058594)
            compare_006.location = (898.5413208007812, -457.4095764160156)
            delete_geometry.location = (1586.16748046875, 279.7948913574219)
            boolean_math_1.location = (1101.0963134765625, -482.2919921875)
            switch.location = (1252.1378173828125, -239.1593475341797)
            group_input_001_1.location = (859.1980590820312, -277.4382629394531)

            #Set dimensions
            group_input_7.width, group_input_7.height = 140.0, 100.0
            group_output_7.width, group_output_7.height = 140.0, 100.0
            group.width, group.height = 140.0, 100.0
            normal_002.width, normal_002.height = 140.0, 100.0
            vector_math_001_1.width, vector_math_001_1.height = 140.0, 100.0
            math_006_1.width, math_006_1.height = 140.0, 100.0
            compare_006.width, compare_006.height = 140.0, 100.0
            delete_geometry.width, delete_geometry.height = 140.0, 100.0
            boolean_math_1.width, boolean_math_1.height = 140.0, 100.0
            switch.width, switch.height = 140.0, 100.0
            group_input_001_1.width, group_input_001_1.height = 140.0, 100.0

            #initialize slope_grouping links
            #group_input_7.Iterations -> group.Iterations
            slope_grouping.links.new(group_input_7.outputs[3], group.inputs[1])
            #group_input_7.Geometry -> group.Geometry
            slope_grouping.links.new(group_input_7.outputs[0], group.inputs[0])
            #normal_002.Normal -> vector_math_001_1.Vector
            slope_grouping.links.new(normal_002.outputs[0], vector_math_001_1.inputs[1])
            #vector_math_001_1.Value -> math_006_1.Value
            slope_grouping.links.new(vector_math_001_1.outputs[1], math_006_1.inputs[0])
            #group.Geometry -> delete_geometry.Geometry
            slope_grouping.links.new(group.outputs[0], delete_geometry.inputs[0])
            #delete_geometry.Geometry -> group_output_7.Geometry
            slope_grouping.links.new(delete_geometry.outputs[0], group_output_7.inputs[0])
            #compare_006.Result -> boolean_math_1.Boolean
            slope_grouping.links.new(compare_006.outputs[0], boolean_math_1.inputs[0])
            #boolean_math_1.Boolean -> switch.True
            slope_grouping.links.new(boolean_math_1.outputs[0], switch.inputs[2])
            #compare_006.Result -> switch.False
            slope_grouping.links.new(compare_006.outputs[0], switch.inputs[1])
            #group_input_001_1.Base/Top -> switch.Switch
            slope_grouping.links.new(group_input_001_1.outputs[1], switch.inputs[0])
            #switch.Output -> delete_geometry.Selection
            slope_grouping.links.new(switch.outputs[0], delete_geometry.inputs[1])
            #math_006_1.Value -> compare_006.A
            slope_grouping.links.new(math_006_1.outputs[0], compare_006.inputs[0])
            #group_input_7.Nor Var -> compare_006.B
            slope_grouping.links.new(group_input_7.outputs[2], compare_006.inputs[1])
            return slope_grouping

        slope_grouping = slope_grouping_node_group()

        #initialize refinemesh node group
        def refinemesh_node_group():
            refinemesh = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "RefineMesh")

            refinemesh.color_tag = 'NONE'
            refinemesh.description = ""
            refinemesh.default_group_node_width = 140
            


            #refinemesh interface
            #Socket ContextMesh
            contextmesh_socket = refinemesh.interface.new_socket(name = "ContextMesh", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            contextmesh_socket.attribute_domain = 'POINT'
            contextmesh_socket.default_input = 'VALUE'
            contextmesh_socket.structure_type = 'AUTO'

            #Socket LeftoverMesh
            leftovermesh_socket = refinemesh.interface.new_socket(name = "LeftoverMesh", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            leftovermesh_socket.attribute_domain = 'POINT'
            leftovermesh_socket.default_input = 'VALUE'
            leftovermesh_socket.structure_type = 'AUTO'

            #Socket Mesh
            mesh_socket = refinemesh.interface.new_socket(name = "Mesh", in_out='INPUT', socket_type = 'NodeSocketGeometry')
            mesh_socket.attribute_domain = 'POINT'
            mesh_socket.default_input = 'VALUE'
            mesh_socket.structure_type = 'AUTO'

            #Socket Polyline
            polyline_socket_1 = refinemesh.interface.new_socket(name = "Polyline", in_out='INPUT', socket_type = 'NodeSocketGeometry')
            polyline_socket_1.attribute_domain = 'POINT'
            polyline_socket_1.default_input = 'VALUE'
            polyline_socket_1.structure_type = 'AUTO'

            #Socket Scale
            scale_socket = refinemesh.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
            scale_socket.default_value = 1.0800000429153442
            scale_socket.min_value = 0.0
            scale_socket.max_value = 3.4028234663852886e+38
            scale_socket.subtype = 'NONE'
            scale_socket.attribute_domain = 'POINT'
            scale_socket.default_input = 'VALUE'
            scale_socket.structure_type = 'AUTO'


            #initialize refinemesh nodes
            #node Group Output
            group_output_8 = refinemesh.nodes.new("NodeGroupOutput")
            group_output_8.name = "Group Output"
            group_output_8.is_active_output = True

            #node Group Input
            group_input_8 = refinemesh.nodes.new("NodeGroupInput")
            group_input_8.name = "Group Input"

            #node Mesh to Curve
            mesh_to_curve = refinemesh.nodes.new("GeometryNodeMeshToCurve")
            mesh_to_curve.name = "Mesh to Curve"
            mesh_to_curve.mode = 'EDGES'
            #Selection
            mesh_to_curve.inputs[1].default_value = True

            #node Set Spline Type
            set_spline_type = refinemesh.nodes.new("GeometryNodeCurveSplineType")
            set_spline_type.name = "Set Spline Type"
            set_spline_type.spline_type = 'BEZIER'
            #Selection
            set_spline_type.inputs[1].default_value = True

            #node Fillet Curve
            fillet_curve = refinemesh.nodes.new("GeometryNodeFilletCurve")
            fillet_curve.name = "Fillet Curve"
            fillet_curve.mode = 'BEZIER'
            #Radius
            fillet_curve.inputs[2].default_value = 0.25
            #Limit Radius
            fillet_curve.inputs[3].default_value = True

            #node Curve to Mesh
            curve_to_mesh = refinemesh.nodes.new("GeometryNodeCurveToMesh")
            curve_to_mesh.name = "Curve to Mesh"
            #Scale
            curve_to_mesh.inputs[2].default_value = 1.0
            #Fill Caps
            curve_to_mesh.inputs[3].default_value = True

            #node Extrude Mesh
            extrude_mesh = refinemesh.nodes.new("GeometryNodeExtrudeMesh")
            extrude_mesh.name = "Extrude Mesh"
            extrude_mesh.mode = 'EDGES'
            #Selection
            extrude_mesh.inputs[1].default_value = True
            #Offset Scale
            extrude_mesh.inputs[3].default_value = 1.0

            #node Vector
            vector = refinemesh.nodes.new("FunctionNodeInputVector")
            vector.name = "Vector"
            vector.vector = (0.0, 0.0, -1.0)

            #node Transform Geometry.001
            transform_geometry_001 = refinemesh.nodes.new("GeometryNodeTransform")
            transform_geometry_001.name = "Transform Geometry.001"
            transform_geometry_001.mode = 'COMPONENTS'
            #Translation
            transform_geometry_001.inputs[1].default_value = (0.0, 0.0, 0.10000000149011612)
            #Rotation
            transform_geometry_001.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Scale
            transform_geometry_001.inputs[3].default_value = (1.0, 1.0, 1.0)

            #node Mesh Boolean
            mesh_boolean = refinemesh.nodes.new("GeometryNodeMeshBoolean")
            mesh_boolean.name = "Mesh Boolean"
            mesh_boolean.operation = 'DIFFERENCE'
            mesh_boolean.solver = 'FLOAT'

            #node Set ID
            set_id = refinemesh.nodes.new("GeometryNodeSetID")
            set_id.name = "Set ID"
            #Selection
            set_id.inputs[1].default_value = True

            #node ID
            id = refinemesh.nodes.new("GeometryNodeInputID")
            id.name = "ID"

            #node Mesh Boolean.001
            mesh_boolean_001 = refinemesh.nodes.new("GeometryNodeMeshBoolean")
            mesh_boolean_001.name = "Mesh Boolean.001"
            mesh_boolean_001.operation = 'INTERSECT'
            mesh_boolean_001.solver = 'FLOAT'

            #node Scale Elements
            scale_elements = refinemesh.nodes.new("GeometryNodeScaleElements")
            scale_elements.name = "Scale Elements"
            scale_elements.domain = 'FACE'
            scale_elements.scale_mode = 'UNIFORM'
            #Selection
            scale_elements.inputs[1].default_value = True
            #Center
            scale_elements.inputs[3].default_value = (0.0, 0.0, 0.0)

            #node Delete Geometry
            delete_geometry_1 = refinemesh.nodes.new("GeometryNodeDeleteGeometry")
            delete_geometry_1.name = "Delete Geometry"
            delete_geometry_1.domain = 'POINT'
            delete_geometry_1.mode = 'ALL'

            #node Compare
            compare = refinemesh.nodes.new("FunctionNodeCompare")
            compare.name = "Compare"
            compare.data_type = 'INT'
            compare.mode = 'ELEMENT'
            compare.operation = 'EQUAL'
            #B_INT
            compare.inputs[3].default_value = -1

            #node ID.001
            id_001 = refinemesh.nodes.new("GeometryNodeInputID")
            id_001.name = "ID.001"

            #node Set ID.001
            set_id_001 = refinemesh.nodes.new("GeometryNodeSetID")
            set_id_001.name = "Set ID.001"
            #Selection
            set_id_001.inputs[1].default_value = True

            #node Integer
            integer = refinemesh.nodes.new("FunctionNodeInputInt")
            integer.name = "Integer"
            integer.integer = -1

            #node Delete Geometry.001
            delete_geometry_001 = refinemesh.nodes.new("GeometryNodeDeleteGeometry")
            delete_geometry_001.name = "Delete Geometry.001"
            delete_geometry_001.domain = 'POINT'
            delete_geometry_001.mode = 'ALL'





            #Set locations
            group_output_8.location = (4400.13134765625, 127.46819305419922)
            group_input_8.location = (-850.9755859375, 0.0)
            mesh_to_curve.location = (-644.6961669921875, -292.12689208984375)
            set_spline_type.location = (-483.0169677734375, -294.9667053222656)
            fillet_curve.location = (-319.6102294921875, -283.28533935546875)
            curve_to_mesh.location = (-149.06483459472656, -271.62542724609375)
            extrude_mesh.location = (1375.3072509765625, -173.939697265625)
            vector.location = (1176.91455078125, -343.8950500488281)
            transform_geometry_001.location = (2793.605224609375, -151.5248260498047)
            mesh_boolean.location = (3582.033447265625, 31.73980140686035)
            set_id.location = (715.6578979492188, 215.5609588623047)
            id.location = (717.8474731445312, 97.67577362060547)
            mesh_boolean_001.location = (3582.860595703125, 245.85487365722656)
            scale_elements.location = (3224.391845703125, -83.06114959716797)
            delete_geometry_1.location = (4096.29296875, 390.9812927246094)
            compare.location = (3938.0986328125, 262.33685302734375)
            id_001.location = (3770.711669921875, 160.3668975830078)
            set_id_001.location = (1726.6976318359375, -213.4075927734375)
            integer.location = (1567.0281982421875, -355.1429443359375)
            delete_geometry_001.location = (4127.32763671875, 109.1408462524414)

            #Set dimensions
            group_output_8.width, group_output_8.height = 140.0, 100.0
            group_input_8.width, group_input_8.height = 140.0, 100.0
            mesh_to_curve.width, mesh_to_curve.height = 140.0, 100.0
            set_spline_type.width, set_spline_type.height = 140.0, 100.0
            fillet_curve.width, fillet_curve.height = 140.0, 100.0
            curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
            extrude_mesh.width, extrude_mesh.height = 152.7578125, 100.0
            vector.width, vector.height = 140.0, 100.0
            transform_geometry_001.width, transform_geometry_001.height = 140.0, 100.0
            mesh_boolean.width, mesh_boolean.height = 140.0, 100.0
            set_id.width, set_id.height = 140.0, 100.0
            id.width, id.height = 140.0, 100.0
            mesh_boolean_001.width, mesh_boolean_001.height = 140.0, 100.0
            scale_elements.width, scale_elements.height = 140.0, 100.0
            delete_geometry_1.width, delete_geometry_1.height = 140.0, 100.0
            compare.width, compare.height = 140.0, 100.0
            id_001.width, id_001.height = 140.0, 100.0
            set_id_001.width, set_id_001.height = 140.0, 100.0
            integer.width, integer.height = 140.0, 100.0
            delete_geometry_001.width, delete_geometry_001.height = 140.0, 100.0

            #initialize refinemesh links
            #fillet_curve.Curve -> curve_to_mesh.Curve
            refinemesh.links.new(fillet_curve.outputs[0], curve_to_mesh.inputs[0])
            #mesh_to_curve.Curve -> set_spline_type.Curve
            refinemesh.links.new(mesh_to_curve.outputs[0], set_spline_type.inputs[0])
            #vector.Vector -> extrude_mesh.Offset
            refinemesh.links.new(vector.outputs[0], extrude_mesh.inputs[2])
            #set_spline_type.Curve -> fillet_curve.Curve
            refinemesh.links.new(set_spline_type.outputs[0], fillet_curve.inputs[0])
            #group_input_8.Polyline -> mesh_to_curve.Mesh
            refinemesh.links.new(group_input_8.outputs[1], mesh_to_curve.inputs[0])
            #id.ID -> set_id.ID
            refinemesh.links.new(id.outputs[0], set_id.inputs[2])
            #set_id.Geometry -> mesh_boolean.Mesh 1
            refinemesh.links.new(set_id.outputs[0], mesh_boolean.inputs[0])
            #group_input_8.Mesh -> set_id.Geometry
            refinemesh.links.new(group_input_8.outputs[0], set_id.inputs[0])
            #transform_geometry_001.Geometry -> scale_elements.Geometry
            refinemesh.links.new(transform_geometry_001.outputs[0], scale_elements.inputs[0])
            #scale_elements.Geometry -> mesh_boolean_001.Mesh
            refinemesh.links.new(scale_elements.outputs[0], mesh_boolean_001.inputs[1])
            #scale_elements.Geometry -> mesh_boolean.Mesh 2
            refinemesh.links.new(scale_elements.outputs[0], mesh_boolean.inputs[1])
            #group_input_8.Scale -> scale_elements.Scale
            refinemesh.links.new(group_input_8.outputs[2], scale_elements.inputs[2])
            #delete_geometry_001.Geometry -> group_output_8.LeftoverMesh
            refinemesh.links.new(delete_geometry_001.outputs[0], group_output_8.inputs[1])
            #curve_to_mesh.Mesh -> extrude_mesh.Mesh
            refinemesh.links.new(curve_to_mesh.outputs[0], extrude_mesh.inputs[0])
            #mesh_boolean_001.Mesh -> delete_geometry_1.Geometry
            refinemesh.links.new(mesh_boolean_001.outputs[0], delete_geometry_1.inputs[0])
            #compare.Result -> delete_geometry_1.Selection
            refinemesh.links.new(compare.outputs[0], delete_geometry_1.inputs[1])
            #id_001.ID -> compare.A
            refinemesh.links.new(id_001.outputs[0], compare.inputs[2])
            #delete_geometry_1.Geometry -> group_output_8.ContextMesh
            refinemesh.links.new(delete_geometry_1.outputs[0], group_output_8.inputs[0])
            #extrude_mesh.Mesh -> set_id_001.Geometry
            refinemesh.links.new(extrude_mesh.outputs[0], set_id_001.inputs[0])
            #integer.Integer -> set_id_001.ID
            refinemesh.links.new(integer.outputs[0], set_id_001.inputs[2])
            #set_id_001.Geometry -> transform_geometry_001.Geometry
            refinemesh.links.new(set_id_001.outputs[0], transform_geometry_001.inputs[0])
            #mesh_boolean.Mesh -> delete_geometry_001.Geometry
            refinemesh.links.new(mesh_boolean.outputs[0], delete_geometry_001.inputs[0])
            #compare.Result -> delete_geometry_001.Selection
            refinemesh.links.new(compare.outputs[0], delete_geometry_001.inputs[1])
            #set_id.Geometry -> mesh_boolean_001.Mesh
            refinemesh.links.new(set_id.outputs[0], mesh_boolean_001.inputs[1])
            return refinemesh

        refinemesh = refinemesh_node_group()

        #initialize archsv node group
        def archsv_node_group():
            archsv = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "ArchSV")

            archsv.color_tag = 'NONE'
            archsv.description = ""
            archsv.default_group_node_width = 140
            

            archsv.is_modifier = True

            #archsv interface
            #Socket Geometry
            geometry_socket_11 = archsv.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_11.attribute_domain = 'POINT'
            geometry_socket_11.default_input = 'VALUE'
            geometry_socket_11.structure_type = 'AUTO'

            #Socket Geometry
            geometry_socket_12 = archsv.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_12.attribute_domain = 'POINT'
            geometry_socket_12.default_input = 'VALUE'
            geometry_socket_12.structure_type = 'AUTO'

            #Socket Base Mesh
            base_mesh_socket = archsv.interface.new_socket(name = "Base Mesh", in_out='INPUT', socket_type = 'NodeSocketObject')
            base_mesh_socket.attribute_domain = 'POINT'
            base_mesh_socket.description = "The base mesh for identification"
            base_mesh_socket.default_input = 'VALUE'
            base_mesh_socket.structure_type = 'AUTO'

            #Socket Guide Mesh
            guide_mesh_socket = archsv.interface.new_socket(name = "Guide Mesh", in_out='INPUT', socket_type = 'NodeSocketObject')
            guide_mesh_socket.attribute_domain = 'POINT'
            guide_mesh_socket.description = "Input if complex meshes above"
            guide_mesh_socket.default_input = 'VALUE'
            guide_mesh_socket.structure_type = 'AUTO'

            #Socket Decimation Ration
            decimation_ration_socket = archsv.interface.new_socket(name = "Decimation Ration", in_out='INPUT', socket_type = 'NodeSocketFloat')
            decimation_ration_socket.default_value = 0.8999999761581421
            decimation_ration_socket.min_value = 0.0
            decimation_ration_socket.max_value = 1.0
            decimation_ration_socket.subtype = 'FACTOR'
            decimation_ration_socket.attribute_domain = 'POINT'
            decimation_ration_socket.description = "Decimate ratio of point cloud used for caluculations"
            decimation_ration_socket.default_input = 'VALUE'
            decimation_ration_socket.structure_type = 'AUTO'

            #Socket XY Variance
            xy_variance_socket = archsv.interface.new_socket(name = "XY Variance", in_out='INPUT', socket_type = 'NodeSocketFloat')
            xy_variance_socket.default_value = 5.0
            xy_variance_socket.min_value = 0.0
            xy_variance_socket.max_value = 100.0
            xy_variance_socket.subtype = 'NONE'
            xy_variance_socket.attribute_domain = 'POINT'
            xy_variance_socket.default_input = 'VALUE'
            xy_variance_socket.structure_type = 'AUTO'

            #Socket Z Variance
            z_variance_socket = archsv.interface.new_socket(name = "Z Variance", in_out='INPUT', socket_type = 'NodeSocketFloat')
            z_variance_socket.default_value = 5.0
            z_variance_socket.min_value = 0.0
            z_variance_socket.max_value = 100.0
            z_variance_socket.subtype = 'NONE'
            z_variance_socket.attribute_domain = 'POINT'
            z_variance_socket.default_input = 'VALUE'
            z_variance_socket.structure_type = 'AUTO'

            #Socket Slope Segmentation
            slope_segmentation_socket = archsv.interface.new_socket(name = "Slope Segmentation", in_out='INPUT', socket_type = 'NodeSocketBool')
            slope_segmentation_socket.default_value = False
            slope_segmentation_socket.attribute_domain = 'POINT'
            slope_segmentation_socket.description = "Segment based on mesh normals. Can aid in the creation of polygons"
            slope_segmentation_socket.default_input = 'VALUE'
            slope_segmentation_socket.structure_type = 'AUTO'

            #Socket Base?
            base__socket = archsv.interface.new_socket(name = "Base?", in_out='INPUT', socket_type = 'NodeSocketBool')
            base__socket.default_value = False
            base__socket.attribute_domain = 'POINT'
            base__socket.description = "Tick if wanting to identify flat surface"
            base__socket.default_input = 'VALUE'
            base__socket.structure_type = 'AUTO'

            #Socket Slope Fac
            slope_fac_socket = archsv.interface.new_socket(name = "Slope Fac", in_out='INPUT', socket_type = 'NodeSocketFloat')
            slope_fac_socket.default_value = 0.30000001192092896
            slope_fac_socket.min_value = 0.0
            slope_fac_socket.max_value = 20.0
            slope_fac_socket.subtype = 'NONE'
            slope_fac_socket.attribute_domain = 'POINT'
            slope_fac_socket.description = "Factor of normal variation to be filitered"
            slope_fac_socket.default_input = 'VALUE'
            slope_fac_socket.structure_type = 'AUTO'

            #Socket Smo It
            smo_it_socket = archsv.interface.new_socket(name = "Smo It", in_out='INPUT', socket_type = 'NodeSocketInt')
            smo_it_socket.default_value = 0
            smo_it_socket.min_value = 0
            smo_it_socket.max_value = 100
            smo_it_socket.subtype = 'FACTOR'
            smo_it_socket.attribute_domain = 'POINT'
            smo_it_socket.description = "Smooth mesh. Note: this makes the geometry less accurate but can make it easier to filter different normals"
            smo_it_socket.default_input = 'VALUE'
            smo_it_socket.structure_type = 'AUTO'

            #Socket Max Z
            max_z_socket = archsv.interface.new_socket(name = "Max Z", in_out='INPUT', socket_type = 'NodeSocketFloat')
            max_z_socket.default_value = 500.0
            max_z_socket.min_value = -10000.0
            max_z_socket.max_value = 10000.0
            max_z_socket.subtype = 'DISTANCE'
            max_z_socket.attribute_domain = 'POINT'
            max_z_socket.description = "Maximum Z value for mesh"
            max_z_socket.default_input = 'VALUE'
            max_z_socket.structure_type = 'AUTO'

            #Socket Min Z
            min_z_socket = archsv.interface.new_socket(name = "Min Z", in_out='INPUT', socket_type = 'NodeSocketFloat')
            min_z_socket.default_value = -0.4399999976158142
            min_z_socket.min_value = -10000.0
            min_z_socket.max_value = 10000.0
            min_z_socket.subtype = 'DISTANCE'
            min_z_socket.attribute_domain = 'POINT'
            min_z_socket.description = "Minimum Z value for mesh"
            min_z_socket.default_input = 'VALUE'
            min_z_socket.structure_type = 'AUTO'

            #Socket Poly Res
            poly_res_socket = archsv.interface.new_socket(name = "Poly Res", in_out='INPUT', socket_type = 'NodeSocketInt')
            poly_res_socket.default_value = 31
            poly_res_socket.min_value = 1
            poly_res_socket.max_value = 100
            poly_res_socket.subtype = 'FACTOR'
            poly_res_socket.attribute_domain = 'POINT'
            poly_res_socket.description = "Ploygon resolution"
            poly_res_socket.default_input = 'VALUE'
            poly_res_socket.structure_type = 'AUTO'

            #Socket Translation
            translation_socket = archsv.interface.new_socket(name = "Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
            translation_socket.default_value = (0.0, 0.0, 0.0)
            translation_socket.min_value = -3.4028234663852886e+38
            translation_socket.max_value = 3.4028234663852886e+38
            translation_socket.subtype = 'TRANSLATION'
            translation_socket.attribute_domain = 'POINT'
            translation_socket.description = "Translate polygon: Note: useful if there is missing geometry above the mesh"
            translation_socket.default_input = 'VALUE'
            translation_socket.structure_type = 'AUTO'

            #Socket Output
            output_socket_1 = archsv.interface.new_socket(name = "Output", in_out='INPUT', socket_type = 'NodeSocketMenu')
            output_socket_1.attribute_domain = 'POINT'
            output_socket_1.default_input = 'VALUE'
            output_socket_1.structure_type = 'AUTO'

            #Socket Volume Resolution
            volume_resolution_socket = archsv.interface.new_socket(name = "Volume Resolution", in_out='INPUT', socket_type = 'NodeSocketFloat')
            volume_resolution_socket.default_value = 100.0
            volume_resolution_socket.min_value = 5.0
            volume_resolution_socket.max_value = 1000.0
            volume_resolution_socket.subtype = 'NONE'
            volume_resolution_socket.attribute_domain = 'POINT'
            volume_resolution_socket.description = "Fine tune value to achieve more accurate results. Higher the better for sphere volume. Lowere the better for voxel volume"
            volume_resolution_socket.default_input = 'VALUE'
            volume_resolution_socket.structure_type = 'AUTO'

            #Socket Volume Sub Level
            volume_sub_level_socket = archsv.interface.new_socket(name = "Volume Sub Level", in_out='INPUT', socket_type = 'NodeSocketInt')
            volume_sub_level_socket.default_value = 6
            volume_sub_level_socket.min_value = 2
            volume_sub_level_socket.max_value = 10
            volume_sub_level_socket.subtype = 'FACTOR'
            volume_sub_level_socket.attribute_domain = 'POINT'
            volume_sub_level_socket.description = "Subdivides mesh and dispalces to match original mesh"
            volume_sub_level_socket.default_input = 'VALUE'
            volume_sub_level_socket.structure_type = 'AUTO'

            #Socket Simplify
            simplify_socket = archsv.interface.new_socket(name = "Simplify", in_out='INPUT', socket_type = 'NodeSocketBool')
            simplify_socket.default_value = False
            simplify_socket.attribute_domain = 'POINT'
            simplify_socket.description = "Simplify mesh"
            simplify_socket.default_input = 'VALUE'
            simplify_socket.structure_type = 'AUTO'

            #Socket End Resolution
            end_resolution_socket = archsv.interface.new_socket(name = "End Resolution", in_out='INPUT', socket_type = 'NodeSocketFloat')
            end_resolution_socket.default_value = 0.029999999329447746
            end_resolution_socket.min_value = 0.0
            end_resolution_socket.max_value = 3.4028234663852886e+38
            end_resolution_socket.subtype = 'DISTANCE'
            end_resolution_socket.attribute_domain = 'POINT'
            end_resolution_socket.description = "Resolution of final mesh"
            end_resolution_socket.default_input = 'VALUE'
            end_resolution_socket.structure_type = 'AUTO'

            #Socket Cutter Scale
            cutter_scale_socket = archsv.interface.new_socket(name = "Cutter Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
            cutter_scale_socket.default_value = 1.0800000429153442
            cutter_scale_socket.min_value = 0.0
            cutter_scale_socket.max_value = 3.4028234663852886e+38
            cutter_scale_socket.subtype = 'FACTOR'
            cutter_scale_socket.attribute_domain = 'POINT'
            cutter_scale_socket.default_input = 'VALUE'
            cutter_scale_socket.structure_type = 'AUTO'

            #Socket Texture Mesh?
            texture_mesh__socket = archsv.interface.new_socket(name = "Texture Mesh?", in_out='INPUT', socket_type = 'NodeSocketBool')
            texture_mesh__socket.default_value = False
            texture_mesh__socket.attribute_domain = 'POINT'
            texture_mesh__socket.description = "Requires guide mesh for proper functionality"
            texture_mesh__socket.default_input = 'VALUE'
            texture_mesh__socket.structure_type = 'AUTO'

            #Socket Material
            material_socket = archsv.interface.new_socket(name = "Material", in_out='INPUT', socket_type = 'NodeSocketMaterial')
            material_socket.attribute_domain = 'POINT'
            material_socket.description = "Select material of guide mesh. If more than one material, bake into a single one"
            material_socket.default_input = 'VALUE'
            material_socket.structure_type = 'AUTO'

            #Socket Texture extension
            texture_extension_socket = archsv.interface.new_socket(name = "Texture extension", in_out='INPUT', socket_type = 'NodeSocketFloat')
            texture_extension_socket.default_value = 0.05000000074505806
            texture_extension_socket.min_value = 0.0
            texture_extension_socket.max_value = 10.0
            texture_extension_socket.subtype = 'DISTANCE'
            texture_extension_socket.attribute_domain = 'POINT'
            texture_extension_socket.description = "Adds texture to Xm below the surface"
            texture_extension_socket.default_input = 'VALUE'
            texture_extension_socket.structure_type = 'AUTO'


            #initialize archsv nodes
            #node Group Output
            group_output_9 = archsv.nodes.new("NodeGroupOutput")
            group_output_9.name = "Group Output"
            group_output_9.is_active_output = True

            #node Object Info
            object_info = archsv.nodes.new("GeometryNodeObjectInfo")
            object_info.name = "Object Info"
            object_info.transform_space = 'RELATIVE'
            #As Instance
            object_info.inputs[1].default_value = False

            #node Mesh to Points
            mesh_to_points = archsv.nodes.new("GeometryNodeMeshToPoints")
            mesh_to_points.name = "Mesh to Points"
            mesh_to_points.mode = 'FACES'
            #Selection
            mesh_to_points.inputs[1].default_value = True
            #Position
            mesh_to_points.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Radius
            mesh_to_points.inputs[3].default_value = 0.009999999776482582

            #node Delete Geometry
            delete_geometry_2 = archsv.nodes.new("GeometryNodeDeleteGeometry")
            delete_geometry_2.name = "Delete Geometry"
            delete_geometry_2.domain = 'POINT'
            delete_geometry_2.mode = 'ALL'

            #node Random Value
            random_value = archsv.nodes.new("FunctionNodeRandomValue")
            random_value.name = "Random Value"
            random_value.hide = True
            random_value.data_type = 'BOOLEAN'
            #ID
            random_value.inputs[7].default_value = 0
            #Seed
            random_value.inputs[8].default_value = 1

            #node Join Geometry
            join_geometry = archsv.nodes.new("GeometryNodeJoinGeometry")
            join_geometry.name = "Join Geometry"

            #node Group
            group_1 = archsv.nodes.new("GeometryNodeGroup")
            group_1.name = "Group"
            group_1.node_tree = volumeapproximation
            #Socket_2
            group_1.inputs[1].default_value = False
            #Socket_3
            group_1.inputs[2].default_value = (1.5, 1.5, 1.5)

            #node Group.001
            group_001_1 = archsv.nodes.new("GeometryNodeGroup")
            group_001_1.name = "Group.001"
            group_001_1.node_tree = seperate_by_xyz

            #node Group.003
            group_003 = archsv.nodes.new("GeometryNodeGroup")
            group_003.name = "Group.003"
            group_003.node_tree = poly_creation

            #node Convex Hull
            convex_hull = archsv.nodes.new("GeometryNodeConvexHull")
            convex_hull.name = "Convex Hull"

            #node Group.002
            group_002 = archsv.nodes.new("GeometryNodeGroup")
            group_002.name = "Group.002"
            group_002.node_tree = slope_grouping

            #node Switch.002
            switch_002 = archsv.nodes.new("GeometryNodeSwitch")
            switch_002.name = "Switch.002"
            switch_002.input_type = 'GEOMETRY'

            #node Compare
            compare_1 = archsv.nodes.new("FunctionNodeCompare")
            compare_1.name = "Compare"
            compare_1.hide = True
            compare_1.data_type = 'FLOAT'
            compare_1.mode = 'ELEMENT'
            compare_1.operation = 'LESS_THAN'

            #node Separate XYZ
            separate_xyz_1 = archsv.nodes.new("ShaderNodeSeparateXYZ")
            separate_xyz_1.name = "Separate XYZ"
            separate_xyz_1.hide = True

            #node Position
            position_2 = archsv.nodes.new("GeometryNodeInputPosition")
            position_2.name = "Position"
            position_2.hide = True

            #node Merge by Distance
            merge_by_distance_1 = archsv.nodes.new("GeometryNodeMergeByDistance")
            merge_by_distance_1.name = "Merge by Distance"
            merge_by_distance_1.mode = 'ALL'
            #Selection
            merge_by_distance_1.inputs[1].default_value = True

            #node Group Input.003
            group_input_003 = archsv.nodes.new("NodeGroupInput")
            group_input_003.name = "Group Input.003"
            group_input_003.outputs[0].hide = True
            group_input_003.outputs[1].hide = True
            group_input_003.outputs[2].hide = True
            group_input_003.outputs[3].hide = True
            group_input_003.outputs[4].hide = True
            group_input_003.outputs[5].hide = True
            group_input_003.outputs[6].hide = True
            group_input_003.outputs[7].hide = True
            group_input_003.outputs[8].hide = True
            group_input_003.outputs[9].hide = True
            group_input_003.outputs[10].hide = True
            group_input_003.outputs[11].hide = True
            group_input_003.outputs[12].hide = True
            group_input_003.outputs[13].hide = True
            group_input_003.outputs[14].hide = True
            group_input_003.outputs[15].hide = True
            group_input_003.outputs[16].hide = True
            group_input_003.outputs[17].hide = True
            group_input_003.outputs[19].hide = True
            group_input_003.outputs[20].hide = True
            group_input_003.outputs[21].hide = True
            group_input_003.outputs[22].hide = True
            group_input_003.outputs[23].hide = True

            #node Object Info.001
            object_info_001 = archsv.nodes.new("GeometryNodeObjectInfo")
            object_info_001.name = "Object Info.001"
            object_info_001.transform_space = 'RELATIVE'
            #As Instance
            object_info_001.inputs[1].default_value = False

            #node Join Geometry.001
            join_geometry_001 = archsv.nodes.new("GeometryNodeJoinGeometry")
            join_geometry_001.name = "Join Geometry.001"

            #node Compare.001
            compare_001 = archsv.nodes.new("FunctionNodeCompare")
            compare_001.name = "Compare.001"
            compare_001.hide = True
            compare_001.data_type = 'FLOAT'
            compare_001.mode = 'ELEMENT'
            compare_001.operation = 'GREATER_THAN'

            #node Group Input.004
            group_input_004 = archsv.nodes.new("NodeGroupInput")
            group_input_004.name = "Group Input.004"
            group_input_004.outputs[0].hide = True
            group_input_004.outputs[1].hide = True
            group_input_004.outputs[2].hide = True
            group_input_004.outputs[3].hide = True
            group_input_004.outputs[4].hide = True
            group_input_004.outputs[5].hide = True
            group_input_004.outputs[6].hide = True
            group_input_004.outputs[10].hide = True
            group_input_004.outputs[11].hide = True
            group_input_004.outputs[12].hide = True
            group_input_004.outputs[13].hide = True
            group_input_004.outputs[14].hide = True
            group_input_004.outputs[15].hide = True
            group_input_004.outputs[16].hide = True
            group_input_004.outputs[17].hide = True
            group_input_004.outputs[18].hide = True
            group_input_004.outputs[19].hide = True
            group_input_004.outputs[20].hide = True
            group_input_004.outputs[21].hide = True
            group_input_004.outputs[22].hide = True
            group_input_004.outputs[23].hide = True

            #node Delete Geometry.001
            delete_geometry_001_1 = archsv.nodes.new("GeometryNodeDeleteGeometry")
            delete_geometry_001_1.name = "Delete Geometry.001"
            delete_geometry_001_1.domain = 'POINT'
            delete_geometry_001_1.mode = 'ALL'

            #node Compare.002
            compare_002_2 = archsv.nodes.new("FunctionNodeCompare")
            compare_002_2.name = "Compare.002"
            compare_002_2.data_type = 'INT'
            compare_002_2.mode = 'ELEMENT'
            compare_002_2.operation = 'LESS_EQUAL'
            #B_INT
            compare_002_2.inputs[3].default_value = 2

            #node Vertex Neighbors
            vertex_neighbors = archsv.nodes.new("GeometryNodeInputMeshVertexNeighbors")
            vertex_neighbors.name = "Vertex Neighbors"

            #node Transform Geometry
            transform_geometry_1 = archsv.nodes.new("GeometryNodeTransform")
            transform_geometry_1.name = "Transform Geometry"
            transform_geometry_1.mode = 'COMPONENTS'
            #Rotation
            transform_geometry_1.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Scale
            transform_geometry_1.inputs[3].default_value = (1.0, 1.0, 1.0)

            #node Boolean Math
            boolean_math_2 = archsv.nodes.new("FunctionNodeBooleanMath")
            boolean_math_2.name = "Boolean Math"
            boolean_math_2.hide = True
            boolean_math_2.operation = 'AND'

            #node Raycast
            raycast_1 = archsv.nodes.new("GeometryNodeRaycast")
            raycast_1.name = "Raycast"
            raycast_1.data_type = 'FLOAT'
            raycast_1.mapping = 'INTERPOLATED'
            #Attribute
            raycast_1.inputs[1].default_value = 0.0
            #Source Position
            raycast_1.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Ray Direction
            raycast_1.inputs[3].default_value = (0.0, 0.0, 1.0)
            #Ray Length
            raycast_1.inputs[4].default_value = 100.0

            #node Delete Geometry.002
            delete_geometry_002 = archsv.nodes.new("GeometryNodeDeleteGeometry")
            delete_geometry_002.name = "Delete Geometry.002"
            delete_geometry_002.domain = 'POINT'
            delete_geometry_002.mode = 'ALL'

            #node Scale Elements
            scale_elements_1 = archsv.nodes.new("GeometryNodeScaleElements")
            scale_elements_1.name = "Scale Elements"
            scale_elements_1.domain = 'FACE'
            scale_elements_1.scale_mode = 'UNIFORM'
            #Selection
            scale_elements_1.inputs[1].default_value = True
            #Scale
            scale_elements_1.inputs[2].default_value = 1.0
            #Center
            scale_elements_1.inputs[3].default_value = (0.0, 0.0, 0.0)

            #node Boolean Math.001
            boolean_math_001_1 = archsv.nodes.new("FunctionNodeBooleanMath")
            boolean_math_001_1.name = "Boolean Math.001"
            boolean_math_001_1.operation = 'NOT'

            #node Switch.003
            switch_003 = archsv.nodes.new("GeometryNodeSwitch")
            switch_003.name = "Switch.003"
            switch_003.input_type = 'GEOMETRY'

            #node Group Input.002
            group_input_002 = archsv.nodes.new("NodeGroupInput")
            group_input_002.name = "Group Input.002"
            group_input_002.outputs[0].hide = True
            group_input_002.outputs[1].hide = True
            group_input_002.outputs[2].hide = True
            group_input_002.outputs[3].hide = True
            group_input_002.outputs[4].hide = True
            group_input_002.outputs[5].hide = True
            group_input_002.outputs[6].hide = True
            group_input_002.outputs[7].hide = True
            group_input_002.outputs[8].hide = True
            group_input_002.outputs[9].hide = True
            group_input_002.outputs[10].hide = True
            group_input_002.outputs[11].hide = True
            group_input_002.outputs[12].hide = True
            group_input_002.outputs[13].hide = True
            group_input_002.outputs[14].hide = True
            group_input_002.outputs[15].hide = True
            group_input_002.outputs[16].hide = True
            group_input_002.outputs[18].hide = True
            group_input_002.outputs[19].hide = True
            group_input_002.outputs[20].hide = True
            group_input_002.outputs[21].hide = True
            group_input_002.outputs[22].hide = True
            group_input_002.outputs[23].hide = True

            #node Reroute
            reroute = archsv.nodes.new("NodeReroute")
            reroute.name = "Reroute"
            reroute.hide = True
            reroute.socket_idname = "NodeSocketGeometry"
            #node Reroute.001
            reroute_001 = archsv.nodes.new("NodeReroute")
            reroute_001.name = "Reroute.001"
            reroute_001.socket_idname = "NodeSocketGeometry"
            #node Reroute.004
            reroute_004 = archsv.nodes.new("NodeReroute")
            reroute_004.name = "Reroute.004"
            reroute_004.hide = True
            reroute_004.socket_idname = "NodeSocketGeometry"
            #node Reroute.006
            reroute_006 = archsv.nodes.new("NodeReroute")
            reroute_006.name = "Reroute.006"
            reroute_006.socket_idname = "NodeSocketGeometry"
            #node Reroute.007
            reroute_007 = archsv.nodes.new("NodeReroute")
            reroute_007.name = "Reroute.007"
            reroute_007.socket_idname = "NodeSocketGeometry"
            #node Reroute.008
            reroute_008 = archsv.nodes.new("NodeReroute")
            reroute_008.name = "Reroute.008"
            reroute_008.socket_idname = "NodeSocketGeometry"
            #node Object Info.002
            object_info_002 = archsv.nodes.new("GeometryNodeObjectInfo")
            object_info_002.name = "Object Info.002"
            object_info_002.transform_space = 'ORIGINAL'
            #As Instance
            object_info_002.inputs[1].default_value = False

            #node Attribute Statistic
            attribute_statistic_3 = archsv.nodes.new("GeometryNodeAttributeStatistic")
            attribute_statistic_3.name = "Attribute Statistic"
            attribute_statistic_3.data_type = 'FLOAT'
            attribute_statistic_3.domain = 'POINT'
            #Selection
            attribute_statistic_3.inputs[1].default_value = True

            #node Index
            index_1 = archsv.nodes.new("GeometryNodeInputIndex")
            index_1.name = "Index"

            #node Compare.003
            compare_003_1 = archsv.nodes.new("FunctionNodeCompare")
            compare_003_1.name = "Compare.003"
            compare_003_1.data_type = 'FLOAT'
            compare_003_1.mode = 'ELEMENT'
            compare_003_1.operation = 'GREATER_THAN'
            #B
            compare_003_1.inputs[1].default_value = 0.0

            #node Switch.005
            switch_005 = archsv.nodes.new("GeometryNodeSwitch")
            switch_005.name = "Switch.005"
            switch_005.input_type = 'GEOMETRY'

            #node Frame
            frame_2 = archsv.nodes.new("NodeFrame")
            frame_2.label = "Join geometry of meshes prior to analysis"
            frame_2.name = "Frame"
            frame_2.label_size = 20
            frame_2.shrink = True

            #node Frame.001
            frame_001_1 = archsv.nodes.new("NodeFrame")
            frame_001_1.label = "simplify pointcould"
            frame_001_1.name = "Frame.001"
            frame_001_1.label_size = 20
            frame_001_1.shrink = True

            #node Frame.002
            frame_002 = archsv.nodes.new("NodeFrame")
            frame_002.label = "XYZ variation filtering"
            frame_002.name = "Frame.002"
            frame_002.label_size = 20
            frame_002.shrink = True

            #node Frame.003
            frame_003 = archsv.nodes.new("NodeFrame")
            frame_003.label = "Creation of polygon with option to transform polygon"
            frame_003.name = "Frame.003"
            frame_003.label_size = 20
            frame_003.shrink = True

            #node Frame.004
            frame_004 = archsv.nodes.new("NodeFrame")
            frame_004.label = "Delete geometry not within polygon bounds"
            frame_004.name = "Frame.004"
            frame_004.label_size = 20
            frame_004.shrink = True

            #node Frame.005
            frame_005 = archsv.nodes.new("NodeFrame")
            frame_005.label = "determine whether there is a guiding mesh"
            frame_005.name = "Frame.005"
            frame_005.label_size = 20
            frame_005.shrink = True

            #node Frame.006
            frame_006 = archsv.nodes.new("NodeFrame")
            frame_006.label = "volume approximation"
            frame_006.name = "Frame.006"
            frame_006.label_size = 20
            frame_006.shrink = True

            #node Frame.008
            frame_008 = archsv.nodes.new("NodeFrame")
            frame_008.label = "mesh simplification"
            frame_008.name = "Frame.008"
            frame_008.label_size = 20
            frame_008.shrink = True

            #node Menu Switch
            menu_switch = archsv.nodes.new("GeometryNodeMenuSwitch")
            menu_switch.name = "Menu Switch"
            menu_switch.active_index = 6
            menu_switch.data_type = 'GEOMETRY'
            menu_switch.enum_items.clear()
            menu_switch.enum_items.new("PreViz Mesh")
            menu_switch.enum_items[0].description = "Mesh for rapid calucluation and segmentation"
            menu_switch.enum_items.new("Polyline")
            menu_switch.enum_items[1].description = "Polyline based on segmentation"
            menu_switch.enum_items.new("Polygon")
            menu_switch.enum_items[2].description = "Infilling of polyline"
            menu_switch.enum_items.new("SphereVolume")
            menu_switch.enum_items[3].description = "Sphere volume calculation"
            menu_switch.enum_items.new("VoxelVolume")
            menu_switch.enum_items[4].description = "Voxel volume calculation"
            menu_switch.enum_items.new("RefinedMesh")
            menu_switch.enum_items[5].description = "Refined mesh using boolean operator"
            menu_switch.enum_items.new("LeftoverMesh")
            menu_switch.enum_items[6].description = "Iverse of refined mesh"

            #node Delete Geometry.003
            delete_geometry_003 = archsv.nodes.new("GeometryNodeDeleteGeometry")
            delete_geometry_003.name = "Delete Geometry.003"
            delete_geometry_003.domain = 'FACE'
            delete_geometry_003.mode = 'ALL'

            #node Boolean Math.002
            boolean_math_002_1 = archsv.nodes.new("FunctionNodeBooleanMath")
            boolean_math_002_1.name = "Boolean Math.002"
            boolean_math_002_1.hide = True
            boolean_math_002_1.operation = 'NOT'

            #node Reroute.002
            reroute_002 = archsv.nodes.new("NodeReroute")
            reroute_002.name = "Reroute.002"
            reroute_002.socket_idname = "NodeSocketGeometry"
            #node Group Input.005
            group_input_005 = archsv.nodes.new("NodeGroupInput")
            group_input_005.name = "Group Input.005"
            group_input_005.hide = True
            group_input_005.outputs[0].hide = True
            group_input_005.outputs[1].hide = True
            group_input_005.outputs[2].hide = True
            group_input_005.outputs[3].hide = True
            group_input_005.outputs[4].hide = True
            group_input_005.outputs[5].hide = True
            group_input_005.outputs[6].hide = True
            group_input_005.outputs[7].hide = True
            group_input_005.outputs[8].hide = True
            group_input_005.outputs[9].hide = True
            group_input_005.outputs[10].hide = True
            group_input_005.outputs[11].hide = True
            group_input_005.outputs[12].hide = True
            group_input_005.outputs[13].hide = True
            group_input_005.outputs[14].hide = True
            group_input_005.outputs[15].hide = True
            group_input_005.outputs[17].hide = True
            group_input_005.outputs[18].hide = True
            group_input_005.outputs[19].hide = True
            group_input_005.outputs[20].hide = True
            group_input_005.outputs[21].hide = True
            group_input_005.outputs[22].hide = True
            group_input_005.outputs[23].hide = True

            #node Group Input.006
            group_input_006 = archsv.nodes.new("NodeGroupInput")
            group_input_006.name = "Group Input.006"
            group_input_006.hide = True
            group_input_006.outputs[0].hide = True
            group_input_006.outputs[1].hide = True
            group_input_006.outputs[2].hide = True
            group_input_006.outputs[3].hide = True
            group_input_006.outputs[4].hide = True
            group_input_006.outputs[5].hide = True
            group_input_006.outputs[6].hide = True
            group_input_006.outputs[7].hide = True
            group_input_006.outputs[8].hide = True
            group_input_006.outputs[9].hide = True
            group_input_006.outputs[10].hide = True
            group_input_006.outputs[11].hide = True
            group_input_006.outputs[12].hide = True
            group_input_006.outputs[13].hide = True
            group_input_006.outputs[14].hide = True
            group_input_006.outputs[16].hide = True
            group_input_006.outputs[17].hide = True
            group_input_006.outputs[18].hide = True
            group_input_006.outputs[19].hide = True
            group_input_006.outputs[20].hide = True
            group_input_006.outputs[21].hide = True
            group_input_006.outputs[22].hide = True
            group_input_006.outputs[23].hide = True

            #node Group Input.007
            group_input_007 = archsv.nodes.new("NodeGroupInput")
            group_input_007.name = "Group Input.007"
            group_input_007.outputs[0].hide = True
            group_input_007.outputs[1].hide = True
            group_input_007.outputs[2].hide = True
            group_input_007.outputs[3].hide = True
            group_input_007.outputs[4].hide = True
            group_input_007.outputs[5].hide = True
            group_input_007.outputs[6].hide = True
            group_input_007.outputs[7].hide = True
            group_input_007.outputs[8].hide = True
            group_input_007.outputs[9].hide = True
            group_input_007.outputs[10].hide = True
            group_input_007.outputs[11].hide = True
            group_input_007.outputs[12].hide = True
            group_input_007.outputs[13].hide = True
            group_input_007.outputs[15].hide = True
            group_input_007.outputs[16].hide = True
            group_input_007.outputs[17].hide = True
            group_input_007.outputs[18].hide = True
            group_input_007.outputs[19].hide = True
            group_input_007.outputs[20].hide = True
            group_input_007.outputs[21].hide = True
            group_input_007.outputs[22].hide = True
            group_input_007.outputs[23].hide = True

            #node Group Input.008
            group_input_008 = archsv.nodes.new("NodeGroupInput")
            group_input_008.name = "Group Input.008"
            group_input_008.outputs[0].hide = True
            group_input_008.outputs[3].hide = True
            group_input_008.outputs[4].hide = True
            group_input_008.outputs[5].hide = True
            group_input_008.outputs[6].hide = True
            group_input_008.outputs[7].hide = True
            group_input_008.outputs[8].hide = True
            group_input_008.outputs[9].hide = True
            group_input_008.outputs[10].hide = True
            group_input_008.outputs[11].hide = True
            group_input_008.outputs[12].hide = True
            group_input_008.outputs[13].hide = True
            group_input_008.outputs[14].hide = True
            group_input_008.outputs[15].hide = True
            group_input_008.outputs[16].hide = True
            group_input_008.outputs[17].hide = True
            group_input_008.outputs[18].hide = True
            group_input_008.outputs[19].hide = True
            group_input_008.outputs[20].hide = True
            group_input_008.outputs[21].hide = True
            group_input_008.outputs[22].hide = True
            group_input_008.outputs[23].hide = True

            #node Group Input.001
            group_input_001_2 = archsv.nodes.new("NodeGroupInput")
            group_input_001_2.name = "Group Input.001"
            group_input_001_2.outputs[1].hide = True
            group_input_001_2.outputs[2].hide = True
            group_input_001_2.outputs[3].hide = True
            group_input_001_2.outputs[4].hide = True
            group_input_001_2.outputs[5].hide = True
            group_input_001_2.outputs[6].hide = True
            group_input_001_2.outputs[7].hide = True
            group_input_001_2.outputs[8].hide = True
            group_input_001_2.outputs[9].hide = True
            group_input_001_2.outputs[10].hide = True
            group_input_001_2.outputs[11].hide = True
            group_input_001_2.outputs[12].hide = True
            group_input_001_2.outputs[13].hide = True
            group_input_001_2.outputs[14].hide = True
            group_input_001_2.outputs[15].hide = True
            group_input_001_2.outputs[16].hide = True
            group_input_001_2.outputs[17].hide = True
            group_input_001_2.outputs[18].hide = True
            group_input_001_2.outputs[19].hide = True
            group_input_001_2.outputs[20].hide = True
            group_input_001_2.outputs[21].hide = True
            group_input_001_2.outputs[22].hide = True
            group_input_001_2.outputs[23].hide = True

            #node Group Input.009
            group_input_009 = archsv.nodes.new("NodeGroupInput")
            group_input_009.name = "Group Input.009"
            group_input_009.outputs[0].hide = True
            group_input_009.outputs[1].hide = True
            group_input_009.outputs[2].hide = True
            group_input_009.outputs[4].hide = True
            group_input_009.outputs[5].hide = True
            group_input_009.outputs[6].hide = True
            group_input_009.outputs[7].hide = True
            group_input_009.outputs[8].hide = True
            group_input_009.outputs[9].hide = True
            group_input_009.outputs[10].hide = True
            group_input_009.outputs[11].hide = True
            group_input_009.outputs[12].hide = True
            group_input_009.outputs[13].hide = True
            group_input_009.outputs[14].hide = True
            group_input_009.outputs[15].hide = True
            group_input_009.outputs[16].hide = True
            group_input_009.outputs[17].hide = True
            group_input_009.outputs[18].hide = True
            group_input_009.outputs[19].hide = True
            group_input_009.outputs[20].hide = True
            group_input_009.outputs[21].hide = True
            group_input_009.outputs[22].hide = True
            group_input_009.outputs[23].hide = True

            #node Group Input.010
            group_input_010 = archsv.nodes.new("NodeGroupInput")
            group_input_010.name = "Group Input.010"
            group_input_010.outputs[0].hide = True
            group_input_010.outputs[2].hide = True
            group_input_010.outputs[3].hide = True
            group_input_010.outputs[4].hide = True
            group_input_010.outputs[5].hide = True
            group_input_010.outputs[6].hide = True
            group_input_010.outputs[7].hide = True
            group_input_010.outputs[8].hide = True
            group_input_010.outputs[9].hide = True
            group_input_010.outputs[10].hide = True
            group_input_010.outputs[11].hide = True
            group_input_010.outputs[12].hide = True
            group_input_010.outputs[13].hide = True
            group_input_010.outputs[14].hide = True
            group_input_010.outputs[15].hide = True
            group_input_010.outputs[16].hide = True
            group_input_010.outputs[17].hide = True
            group_input_010.outputs[18].hide = True
            group_input_010.outputs[19].hide = True
            group_input_010.outputs[20].hide = True
            group_input_010.outputs[21].hide = True
            group_input_010.outputs[22].hide = True
            group_input_010.outputs[23].hide = True

            #node Group Input.011
            group_input_011 = archsv.nodes.new("NodeGroupInput")
            group_input_011.name = "Group Input.011"
            group_input_011.outputs[0].hide = True
            group_input_011.outputs[1].hide = True
            group_input_011.outputs[3].hide = True
            group_input_011.outputs[4].hide = True
            group_input_011.outputs[5].hide = True
            group_input_011.outputs[6].hide = True
            group_input_011.outputs[7].hide = True
            group_input_011.outputs[8].hide = True
            group_input_011.outputs[9].hide = True
            group_input_011.outputs[10].hide = True
            group_input_011.outputs[11].hide = True
            group_input_011.outputs[12].hide = True
            group_input_011.outputs[13].hide = True
            group_input_011.outputs[14].hide = True
            group_input_011.outputs[15].hide = True
            group_input_011.outputs[16].hide = True
            group_input_011.outputs[17].hide = True
            group_input_011.outputs[18].hide = True
            group_input_011.outputs[19].hide = True
            group_input_011.outputs[20].hide = True
            group_input_011.outputs[21].hide = True
            group_input_011.outputs[22].hide = True
            group_input_011.outputs[23].hide = True

            #node Group Input
            group_input_9 = archsv.nodes.new("NodeGroupInput")
            group_input_9.name = "Group Input"
            group_input_9.outputs[0].hide = True
            group_input_9.outputs[1].hide = True
            group_input_9.outputs[2].hide = True
            group_input_9.outputs[3].hide = True
            group_input_9.outputs[4].hide = True
            group_input_9.outputs[5].hide = True
            group_input_9.outputs[6].hide = True
            group_input_9.outputs[7].hide = True
            group_input_9.outputs[8].hide = True
            group_input_9.outputs[9].hide = True
            group_input_9.outputs[10].hide = True
            group_input_9.outputs[11].hide = True
            group_input_9.outputs[13].hide = True
            group_input_9.outputs[14].hide = True
            group_input_9.outputs[15].hide = True
            group_input_9.outputs[16].hide = True
            group_input_9.outputs[17].hide = True
            group_input_9.outputs[18].hide = True
            group_input_9.outputs[19].hide = True
            group_input_9.outputs[20].hide = True
            group_input_9.outputs[21].hide = True
            group_input_9.outputs[22].hide = True
            group_input_9.outputs[23].hide = True

            #node Group Input.012
            group_input_012 = archsv.nodes.new("NodeGroupInput")
            group_input_012.name = "Group Input.012"
            group_input_012.outputs[0].hide = True
            group_input_012.outputs[1].hide = True
            group_input_012.outputs[2].hide = True
            group_input_012.outputs[3].hide = True
            group_input_012.outputs[4].hide = True
            group_input_012.outputs[5].hide = True
            group_input_012.outputs[6].hide = True
            group_input_012.outputs[7].hide = True
            group_input_012.outputs[8].hide = True
            group_input_012.outputs[9].hide = True
            group_input_012.outputs[10].hide = True
            group_input_012.outputs[11].hide = True
            group_input_012.outputs[12].hide = True
            group_input_012.outputs[14].hide = True
            group_input_012.outputs[15].hide = True
            group_input_012.outputs[16].hide = True
            group_input_012.outputs[17].hide = True
            group_input_012.outputs[18].hide = True
            group_input_012.outputs[19].hide = True
            group_input_012.outputs[20].hide = True
            group_input_012.outputs[21].hide = True
            group_input_012.outputs[22].hide = True
            group_input_012.outputs[23].hide = True

            #node Reroute.003
            reroute_003 = archsv.nodes.new("NodeReroute")
            reroute_003.name = "Reroute.003"
            reroute_003.socket_idname = "NodeSocketGeometry"
            #node Reroute.005
            reroute_005 = archsv.nodes.new("NodeReroute")
            reroute_005.name = "Reroute.005"
            reroute_005.socket_idname = "NodeSocketGeometry"
            #node Reroute.009
            reroute_009 = archsv.nodes.new("NodeReroute")
            reroute_009.name = "Reroute.009"
            reroute_009.socket_idname = "NodeSocketGeometry"
            #node Reroute.010
            reroute_010 = archsv.nodes.new("NodeReroute")
            reroute_010.name = "Reroute.010"
            reroute_010.socket_idname = "NodeSocketGeometry"
            #node Reroute.011
            reroute_011 = archsv.nodes.new("NodeReroute")
            reroute_011.name = "Reroute.011"
            reroute_011.socket_idname = "NodeSocketGeometry"
            #node Group Input.013
            group_input_013 = archsv.nodes.new("NodeGroupInput")
            group_input_013.name = "Group Input.013"
            group_input_013.outputs[0].hide = True
            group_input_013.outputs[1].hide = True
            group_input_013.outputs[2].hide = True
            group_input_013.outputs[3].hide = True
            group_input_013.outputs[5].hide = True
            group_input_013.outputs[6].hide = True
            group_input_013.outputs[7].hide = True
            group_input_013.outputs[8].hide = True
            group_input_013.outputs[9].hide = True
            group_input_013.outputs[10].hide = True
            group_input_013.outputs[11].hide = True
            group_input_013.outputs[12].hide = True
            group_input_013.outputs[13].hide = True
            group_input_013.outputs[14].hide = True
            group_input_013.outputs[15].hide = True
            group_input_013.outputs[16].hide = True
            group_input_013.outputs[17].hide = True
            group_input_013.outputs[18].hide = True
            group_input_013.outputs[19].hide = True
            group_input_013.outputs[20].hide = True
            group_input_013.outputs[21].hide = True
            group_input_013.outputs[22].hide = True
            group_input_013.outputs[23].hide = True

            #node Group Input.014
            group_input_014 = archsv.nodes.new("NodeGroupInput")
            group_input_014.name = "Group Input.014"
            group_input_014.outputs[0].hide = True
            group_input_014.outputs[1].hide = True
            group_input_014.outputs[2].hide = True
            group_input_014.outputs[3].hide = True
            group_input_014.outputs[4].hide = True
            group_input_014.outputs[6].hide = True
            group_input_014.outputs[7].hide = True
            group_input_014.outputs[8].hide = True
            group_input_014.outputs[9].hide = True
            group_input_014.outputs[10].hide = True
            group_input_014.outputs[11].hide = True
            group_input_014.outputs[12].hide = True
            group_input_014.outputs[13].hide = True
            group_input_014.outputs[14].hide = True
            group_input_014.outputs[15].hide = True
            group_input_014.outputs[16].hide = True
            group_input_014.outputs[17].hide = True
            group_input_014.outputs[18].hide = True
            group_input_014.outputs[19].hide = True
            group_input_014.outputs[20].hide = True
            group_input_014.outputs[21].hide = True
            group_input_014.outputs[22].hide = True
            group_input_014.outputs[23].hide = True

            #node Group Input.015
            group_input_015 = archsv.nodes.new("NodeGroupInput")
            group_input_015.name = "Group Input.015"
            group_input_015.outputs[0].hide = True
            group_input_015.outputs[1].hide = True
            group_input_015.outputs[2].hide = True
            group_input_015.outputs[3].hide = True
            group_input_015.outputs[4].hide = True
            group_input_015.outputs[5].hide = True
            group_input_015.outputs[6].hide = True
            group_input_015.outputs[7].hide = True
            group_input_015.outputs[8].hide = True
            group_input_015.outputs[9].hide = True
            group_input_015.outputs[11].hide = True
            group_input_015.outputs[12].hide = True
            group_input_015.outputs[13].hide = True
            group_input_015.outputs[14].hide = True
            group_input_015.outputs[15].hide = True
            group_input_015.outputs[16].hide = True
            group_input_015.outputs[17].hide = True
            group_input_015.outputs[18].hide = True
            group_input_015.outputs[19].hide = True
            group_input_015.outputs[20].hide = True
            group_input_015.outputs[21].hide = True
            group_input_015.outputs[22].hide = True
            group_input_015.outputs[23].hide = True

            #node Group Input.016
            group_input_016 = archsv.nodes.new("NodeGroupInput")
            group_input_016.name = "Group Input.016"
            group_input_016.outputs[0].hide = True
            group_input_016.outputs[1].hide = True
            group_input_016.outputs[2].hide = True
            group_input_016.outputs[3].hide = True
            group_input_016.outputs[4].hide = True
            group_input_016.outputs[5].hide = True
            group_input_016.outputs[6].hide = True
            group_input_016.outputs[7].hide = True
            group_input_016.outputs[8].hide = True
            group_input_016.outputs[9].hide = True
            group_input_016.outputs[10].hide = True
            group_input_016.outputs[12].hide = True
            group_input_016.outputs[13].hide = True
            group_input_016.outputs[14].hide = True
            group_input_016.outputs[15].hide = True
            group_input_016.outputs[16].hide = True
            group_input_016.outputs[17].hide = True
            group_input_016.outputs[18].hide = True
            group_input_016.outputs[19].hide = True
            group_input_016.outputs[20].hide = True
            group_input_016.outputs[21].hide = True
            group_input_016.outputs[22].hide = True
            group_input_016.outputs[23].hide = True

            #node Group Input.017
            group_input_017 = archsv.nodes.new("NodeGroupInput")
            group_input_017.name = "Group Input.017"
            group_input_017.outputs[0].hide = True
            group_input_017.outputs[1].hide = True
            group_input_017.outputs[2].hide = True
            group_input_017.outputs[3].hide = True
            group_input_017.outputs[4].hide = True
            group_input_017.outputs[5].hide = True
            group_input_017.outputs[7].hide = True
            group_input_017.outputs[8].hide = True
            group_input_017.outputs[9].hide = True
            group_input_017.outputs[10].hide = True
            group_input_017.outputs[11].hide = True
            group_input_017.outputs[12].hide = True
            group_input_017.outputs[13].hide = True
            group_input_017.outputs[14].hide = True
            group_input_017.outputs[15].hide = True
            group_input_017.outputs[16].hide = True
            group_input_017.outputs[17].hide = True
            group_input_017.outputs[18].hide = True
            group_input_017.outputs[19].hide = True
            group_input_017.outputs[20].hide = True
            group_input_017.outputs[21].hide = True
            group_input_017.outputs[22].hide = True
            group_input_017.outputs[23].hide = True

            #node Group.004
            group_004 = archsv.nodes.new("GeometryNodeGroup")
            group_004.name = "Group.004"
            group_004.node_tree = refinemesh

            #node Group Input.018
            group_input_018 = archsv.nodes.new("NodeGroupInput")
            group_input_018.name = "Group Input.018"
            group_input_018.outputs[0].hide = True
            group_input_018.outputs[1].hide = True
            group_input_018.outputs[2].hide = True
            group_input_018.outputs[3].hide = True
            group_input_018.outputs[4].hide = True
            group_input_018.outputs[5].hide = True
            group_input_018.outputs[6].hide = True
            group_input_018.outputs[7].hide = True
            group_input_018.outputs[8].hide = True
            group_input_018.outputs[9].hide = True
            group_input_018.outputs[10].hide = True
            group_input_018.outputs[11].hide = True
            group_input_018.outputs[12].hide = True
            group_input_018.outputs[13].hide = True
            group_input_018.outputs[14].hide = True
            group_input_018.outputs[15].hide = True
            group_input_018.outputs[16].hide = True
            group_input_018.outputs[17].hide = True
            group_input_018.outputs[18].hide = True
            group_input_018.outputs[20].hide = True
            group_input_018.outputs[21].hide = True
            group_input_018.outputs[22].hide = True
            group_input_018.outputs[23].hide = True

            #node Object Info.003
            object_info_003 = archsv.nodes.new("GeometryNodeObjectInfo")
            object_info_003.name = "Object Info.003"
            object_info_003.transform_space = 'RELATIVE'
            #As Instance
            object_info_003.inputs[1].default_value = False

            #node Raycast.001
            raycast_001 = archsv.nodes.new("GeometryNodeRaycast")
            raycast_001.name = "Raycast.001"
            raycast_001.data_type = 'FLOAT_VECTOR'
            raycast_001.mapping = 'INTERPOLATED'
            #Source Position
            raycast_001.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Ray Direction
            raycast_001.inputs[3].default_value = (0.0, 0.0, 1.0)

            #node Named Attribute
            named_attribute = archsv.nodes.new("GeometryNodeInputNamedAttribute")
            named_attribute.name = "Named Attribute"
            named_attribute.data_type = 'FLOAT_VECTOR'
            #Name
            named_attribute.inputs[0].default_value = "UVMap"

            #node Transform Geometry.001
            transform_geometry_001_1 = archsv.nodes.new("GeometryNodeTransform")
            transform_geometry_001_1.name = "Transform Geometry.001"
            transform_geometry_001_1.mode = 'COMPONENTS'
            #Translation
            transform_geometry_001_1.inputs[1].default_value = (0.0, 0.0, 1.0)
            #Rotation
            transform_geometry_001_1.inputs[2].default_value = (0.0, 0.0, 0.0)
            #Scale
            transform_geometry_001_1.inputs[3].default_value = (1.0, 1.0, 1.0)

            #node Store Named Attribute
            store_named_attribute = archsv.nodes.new("GeometryNodeStoreNamedAttribute")
            store_named_attribute.name = "Store Named Attribute"
            store_named_attribute.data_type = 'FLOAT2'
            store_named_attribute.domain = 'CORNER'
            #Selection
            store_named_attribute.inputs[1].default_value = True
            #Name
            store_named_attribute.inputs[2].default_value = "UVMap"

            #node Set Material
            set_material = archsv.nodes.new("GeometryNodeSetMaterial")
            set_material.name = "Set Material"
            #Selection
            set_material.inputs[1].default_value = True

            #node Group Input.020
            group_input_020 = archsv.nodes.new("NodeGroupInput")
            group_input_020.name = "Group Input.020"

            #node Group Input.019
            group_input_019 = archsv.nodes.new("NodeGroupInput")
            group_input_019.name = "Group Input.019"
            group_input_019.outputs[0].hide = True
            group_input_019.outputs[1].hide = True
            group_input_019.outputs[2].hide = True
            group_input_019.outputs[3].hide = True
            group_input_019.outputs[4].hide = True
            group_input_019.outputs[5].hide = True
            group_input_019.outputs[6].hide = True
            group_input_019.outputs[7].hide = True
            group_input_019.outputs[8].hide = True
            group_input_019.outputs[9].hide = True
            group_input_019.outputs[10].hide = True
            group_input_019.outputs[11].hide = True
            group_input_019.outputs[12].hide = True
            group_input_019.outputs[13].hide = True
            group_input_019.outputs[14].hide = True
            group_input_019.outputs[15].hide = True
            group_input_019.outputs[16].hide = True
            group_input_019.outputs[17].hide = True
            group_input_019.outputs[18].hide = True
            group_input_019.outputs[19].hide = True
            group_input_019.outputs[20].hide = True
            group_input_019.outputs[22].hide = True
            group_input_019.outputs[23].hide = True

            #node Switch
            switch_1 = archsv.nodes.new("GeometryNodeSwitch")
            switch_1.name = "Switch"
            switch_1.input_type = 'GEOMETRY'

            #node Group Input.021
            group_input_021 = archsv.nodes.new("NodeGroupInput")
            group_input_021.name = "Group Input.021"
            group_input_021.outputs[0].hide = True
            group_input_021.outputs[1].hide = True
            group_input_021.outputs[2].hide = True
            group_input_021.outputs[3].hide = True
            group_input_021.outputs[4].hide = True
            group_input_021.outputs[5].hide = True
            group_input_021.outputs[6].hide = True
            group_input_021.outputs[7].hide = True
            group_input_021.outputs[8].hide = True
            group_input_021.outputs[9].hide = True
            group_input_021.outputs[10].hide = True
            group_input_021.outputs[11].hide = True
            group_input_021.outputs[12].hide = True
            group_input_021.outputs[13].hide = True
            group_input_021.outputs[14].hide = True
            group_input_021.outputs[15].hide = True
            group_input_021.outputs[16].hide = True
            group_input_021.outputs[17].hide = True
            group_input_021.outputs[18].hide = True
            group_input_021.outputs[19].hide = True
            group_input_021.outputs[21].hide = True
            group_input_021.outputs[22].hide = True
            group_input_021.outputs[23].hide = True

            #node Mesh to Volume
            mesh_to_volume_2 = archsv.nodes.new("GeometryNodeMeshToVolume")
            mesh_to_volume_2.name = "Mesh to Volume"
            mesh_to_volume_2.mute = True
            mesh_to_volume_2.resolution_mode = 'VOXEL_AMOUNT'
            #Density
            mesh_to_volume_2.inputs[1].default_value = 1.0
            #Voxel Amount
            mesh_to_volume_2.inputs[3].default_value = 64.0
            #Interior Band Width
            mesh_to_volume_2.inputs[4].default_value = 0.20000000298023224

            #node Volume to Mesh
            volume_to_mesh_2 = archsv.nodes.new("GeometryNodeVolumeToMesh")
            volume_to_mesh_2.name = "Volume to Mesh"
            volume_to_mesh_2.mute = True
            volume_to_mesh_2.resolution_mode = 'GRID'
            #Threshold
            volume_to_mesh_2.inputs[3].default_value = 0.009999999776482582
            #Adaptivity
            volume_to_mesh_2.inputs[4].default_value = 0.0

            #node Math
            math_2 = archsv.nodes.new("ShaderNodeMath")
            math_2.name = "Math"
            math_2.operation = 'ADD'
            math_2.use_clamp = False
            #Value_001
            math_2.inputs[1].default_value = 1.0

            #node Object Info.004
            object_info_004 = archsv.nodes.new("GeometryNodeObjectInfo")
            object_info_004.name = "Object Info.004"
            object_info_004.transform_space = 'ORIGINAL'
            #As Instance
            object_info_004.inputs[1].default_value = False

            #node Reroute.012
            reroute_012 = archsv.nodes.new("NodeReroute")
            reroute_012.name = "Reroute.012"
            reroute_012.socket_idname = "NodeSocketGeometry"
            #node Reroute.013
            reroute_013 = archsv.nodes.new("NodeReroute")
            reroute_013.name = "Reroute.013"
            reroute_013.socket_idname = "NodeSocketGeometry"
            #node Reroute.014
            reroute_014 = archsv.nodes.new("NodeReroute")
            reroute_014.name = "Reroute.014"
            reroute_014.socket_idname = "NodeSocketGeometry"



            #Set parents
            object_info.parent = frame_2
            mesh_to_points.parent = frame_001_1
            delete_geometry_2.parent = frame_001_1
            random_value.parent = frame_001_1
            join_geometry.parent = frame_006
            group_1.parent = frame_006
            group_001_1.parent = frame_002
            group_003.parent = frame_003
            convex_hull.parent = frame_002
            merge_by_distance_1.parent = frame_008
            group_input_003.parent = frame_008
            object_info_001.parent = frame_2
            join_geometry_001.parent = frame_2
            delete_geometry_001_1.parent = frame_008
            compare_002_2.parent = frame_008
            vertex_neighbors.parent = frame_008
            transform_geometry_1.parent = frame_003
            raycast_1.parent = frame_004
            delete_geometry_002.parent = frame_004
            scale_elements_1.parent = frame_004
            boolean_math_001_1.parent = frame_004
            switch_003.parent = frame_008
            group_input_002.parent = frame_008
            object_info_002.parent = frame_005
            attribute_statistic_3.parent = frame_005
            index_1.parent = frame_005
            compare_003_1.parent = frame_005
            switch_005.parent = frame_006
            menu_switch.parent = frame_008
            group_input_005.parent = frame_006
            group_input_006.parent = frame_006
            group_input_009.parent = frame_001_1
            group_input_012.parent = frame_003
            group_input_013.parent = frame_002

            #Set locations
            group_output_9.location = (11992.921875, 355.154296875)
            object_info.location = (30.69744873046875, -36.05572509765625)
            mesh_to_points.location = (35.6396484375, -36.04619598388672)
            delete_geometry_2.location = (205.86761474609375, -62.46739959716797)
            random_value.location = (202.78240966796875, -215.4100799560547)
            join_geometry.location = (29.29248046875, -333.2223205566406)
            group_1.location = (589.87109375, -36.079345703125)
            group_001_1.location = (351.49920654296875, -36.00695037841797)
            group_003.location = (29.276123046875, -112.51959228515625)
            convex_hull.location = (29.03179931640625, -295.46343994140625)
            group_002.location = (1654.13330078125, -487.0401306152344)
            switch_002.location = (1882.9439697265625, -298.5397033691406)
            compare_1.location = (1830.12890625, -771.37060546875)
            separate_xyz_1.location = (1831.4156494140625, -737.195068359375)
            position_2.location = (1830.6929931640625, -705.6486206054688)
            merge_by_distance_1.location = (539.2431640625, -357.22161865234375)
            group_input_003.location = (304.3046875, -422.73748779296875)
            object_info_001.location = (28.97705078125, -230.65280151367188)
            join_geometry_001.location = (406.786865234375, -79.99505615234375)
            compare_001.location = (1833.6826171875, -804.2164916992188)
            group_input_004.location = (1366.611328125, -552.2374877929688)
            delete_geometry_001_1.location = (737.6181640625, -287.8066101074219)
            compare_002_2.location = (731.4169921875, -441.61370849609375)
            vertex_neighbors.location = (737.3466796875, -598.5980224609375)
            transform_geometry_1.location = (336.0361328125, -35.64752197265625)
            boolean_math_2.location = (2006.57861328125, -782.6784057617188)
            raycast_1.location = (211.732177734375, -35.47601318359375)
            delete_geometry_002.location = (574.475830078125, -41.1661376953125)
            scale_elements_1.location = (28.7431640625, -137.01165771484375)
            boolean_math_001_1.location = (388.273681640625, -205.55770874023438)
            switch_003.location = (722.2998046875, -117.7596435546875)
            group_input_002.location = (720.58984375, -35.526580810546875)
            reroute.location = (987.6797485351562, 323.719970703125)
            reroute_001.location = (252.33367919921875, 314.3369445800781)
            reroute_004.location = (4115.23779296875, 323.0516662597656)
            reroute_006.location = (6088.72021484375, -916.142333984375)
            reroute_007.location = (7029.46435546875, -916.142333984375)
            reroute_008.location = (4734.90771484375, -176.3975372314453)
            object_info_002.location = (30.0048828125, -97.703125)
            attribute_statistic_3.location = (218.2919921875, -35.65753173828125)
            index_1.location = (28.828125, -312.0111083984375)
            compare_003_1.location = (408.09765625, -139.28546142578125)
            switch_005.location = (314.041015625, -500.9749755859375)
            frame_2.location = (-1033.0, 431.1333312988281)
            frame_001_1.location = (534.3333129882812, 7.8000006675720215)
            frame_002.location = (969.6666870117188, 25.133333206176758)
            frame_003.location = (3076.333251953125, -818.86669921875)
            frame_004.location = (3868.333251953125, -342.8666687011719)
            frame_005.location = (5840.33349609375, 719.7999877929688)
            frame_006.location = (6329.66650390625, 209.1333465576172)
            frame_008.location = (8349.6669921875, 493.1333312988281)
            menu_switch.location = (28.703125, -175.3155517578125)
            delete_geometry_003.location = (2376.151123046875, -668.2239379882812)
            boolean_math_002_1.location = (2182.274169921875, -782.6648559570312)
            reroute_002.location = (2398.904052734375, 233.62469482421875)
            group_input_005.location = (334.43359375, -247.40025329589844)
            group_input_006.location = (329.197265625, -203.2235107421875)
            group_input_007.location = (8117.62060546875, 315.8629150390625)
            group_input_008.location = (5656.81494140625, 535.8052368164062)
            group_input_001_2.location = (746.59912109375, -293.4263000488281)
            group_input_009.location = (29.2666015625, -210.29159545898438)
            group_input_010.location = (-1202.500732421875, 261.3804626464844)
            group_input_011.location = (-1225.8795166015625, 65.75022888183594)
            group_input_9.location = (2887.9443359375, -1037.66064453125)
            group_input_012.location = (29.71728515625, -50.051513671875)
            reroute_003.location = (3338.921875, -1213.1029052734375)
            reroute_005.location = (6783.87890625, -1255.9334716796875)
            reroute_009.location = (8129.49072265625, 175.2739715576172)
            reroute_010.location = (7027.73046875, -862.3976440429688)
            reroute_011.location = (8129.49072265625, 198.8519744873047)
            group_input_013.location = (30.3997802734375, -146.12411499023438)
            group_input_014.location = (1004.27197265625, -175.68931579589844)
            group_input_015.location = (1624.3897705078125, -748.247802734375)
            group_input_016.location = (1625.8292236328125, -808.7300415039062)
            group_input_017.location = (1650.6856689453125, -118.47991180419922)
            group_004.location = (7431.51611328125, 106.48873138427734)
            group_input_018.location = (7189.76025390625, -7.5440826416015625)
            object_info_003.location = (9282.271484375, 905.43994140625)
            raycast_001.location = (9982.3076171875, 1286.7159423828125)
            named_attribute.location = (9749.0859375, 1229.2569580078125)
            transform_geometry_001_1.location = (9534.64453125, 982.7938842773438)
            store_named_attribute.location = (10311.1005859375, 1281.1392822265625)
            set_material.location = (10506.3759765625, 1213.1129150390625)
            group_input_020.location = (9054.5517578125, 1135.69482421875)
            group_input_019.location = (10324.03125, 1081.6990966796875)
            switch_1.location = (10832.162109375, 431.7676696777344)
            group_input_021.location = (10829.4326171875, 491.9816589355469)
            mesh_to_volume_2.location = (11040.7412109375, 472.519775390625)
            volume_to_mesh_2.location = (11281.6953125, 498.8953857421875)
            math_2.location = (9724.556640625, 949.8557739257812)
            object_info_004.location = (5942.19921875, 131.32106018066406)
            reroute_012.location = (6187.23779296875, 270.10430908203125)
            reroute_013.location = (7340.0, 260.0)
            reroute_014.location = (4206.3173828125, 226.06797790527344)

            #Set dimensions
            group_output_9.width, group_output_9.height = 140.0, 100.0
            object_info.width, object_info.height = 140.0, 100.0
            mesh_to_points.width, mesh_to_points.height = 140.0, 100.0
            delete_geometry_2.width, delete_geometry_2.height = 140.0, 100.0
            random_value.width, random_value.height = 140.0, 100.0
            join_geometry.width, join_geometry.height = 140.0, 100.0
            group_1.width, group_1.height = 182.0169219970703, 100.0
            group_001_1.width, group_001_1.height = 140.0, 100.0
            group_003.width, group_003.height = 140.0, 100.0
            convex_hull.width, convex_hull.height = 140.0, 100.0
            group_002.width, group_002.height = 140.0, 100.0
            switch_002.width, switch_002.height = 140.0, 100.0
            compare_1.width, compare_1.height = 140.0, 100.0
            separate_xyz_1.width, separate_xyz_1.height = 140.0, 100.0
            position_2.width, position_2.height = 140.0, 100.0
            merge_by_distance_1.width, merge_by_distance_1.height = 140.0, 100.0
            group_input_003.width, group_input_003.height = 140.0, 100.0
            object_info_001.width, object_info_001.height = 140.0, 100.0
            join_geometry_001.width, join_geometry_001.height = 140.0, 100.0
            compare_001.width, compare_001.height = 140.0, 100.0
            group_input_004.width, group_input_004.height = 140.0, 100.0
            delete_geometry_001_1.width, delete_geometry_001_1.height = 140.0, 100.0
            compare_002_2.width, compare_002_2.height = 140.0, 100.0
            vertex_neighbors.width, vertex_neighbors.height = 140.0, 100.0
            transform_geometry_1.width, transform_geometry_1.height = 140.0, 100.0
            boolean_math_2.width, boolean_math_2.height = 140.0, 100.0
            raycast_1.width, raycast_1.height = 150.0, 100.0
            delete_geometry_002.width, delete_geometry_002.height = 140.0, 100.0
            scale_elements_1.width, scale_elements_1.height = 140.0, 100.0
            boolean_math_001_1.width, boolean_math_001_1.height = 140.0, 100.0
            switch_003.width, switch_003.height = 140.0, 100.0
            group_input_002.width, group_input_002.height = 140.0, 100.0
            reroute.width, reroute.height = 14.5, 100.0
            reroute_001.width, reroute_001.height = 14.5, 100.0
            reroute_004.width, reroute_004.height = 14.5, 100.0
            reroute_006.width, reroute_006.height = 14.5, 100.0
            reroute_007.width, reroute_007.height = 14.5, 100.0
            reroute_008.width, reroute_008.height = 14.5, 100.0
            object_info_002.width, object_info_002.height = 140.0, 100.0
            attribute_statistic_3.width, attribute_statistic_3.height = 140.0, 100.0
            index_1.width, index_1.height = 140.0, 100.0
            compare_003_1.width, compare_003_1.height = 140.0, 100.0
            switch_005.width, switch_005.height = 140.0, 100.0
            frame_2.width, frame_2.height = 576.0, 461.4666748046875
            frame_001_1.width, frame_001_1.height = 374.66668701171875, 288.79998779296875
            frame_002.width, frame_002.height = 520.6666870117188, 396.1333312988281
            frame_003.width, frame_003.height = 505.33349609375, 316.7999267578125
            frame_004.width, frame_004.height = 743.333251953125, 409.4666442871094
            frame_005.width, frame_005.height = 577.3330078125, 388.79998779296875
            frame_006.width, frame_006.height = 800.68359375, 666.7999877929688
            frame_008.width, frame_008.height = 906.666015625, 696.13330078125
            menu_switch.width, menu_switch.height = 140.0, 100.0
            delete_geometry_003.width, delete_geometry_003.height = 140.0, 100.0
            boolean_math_002_1.width, boolean_math_002_1.height = 140.0, 100.0
            reroute_002.width, reroute_002.height = 14.5, 100.0
            group_input_005.width, group_input_005.height = 133.7897186279297, 100.0
            group_input_006.width, group_input_006.height = 140.0, 100.0
            group_input_007.width, group_input_007.height = 140.0, 100.0
            group_input_008.width, group_input_008.height = 140.0, 100.0
            group_input_001_2.width, group_input_001_2.height = 140.0, 100.0
            group_input_009.width, group_input_009.height = 140.0, 100.0
            group_input_010.width, group_input_010.height = 140.0, 100.0
            group_input_011.width, group_input_011.height = 140.0, 100.0
            group_input_9.width, group_input_9.height = 140.0, 100.0
            group_input_012.width, group_input_012.height = 140.0, 100.0
            reroute_003.width, reroute_003.height = 14.5, 100.0
            reroute_005.width, reroute_005.height = 14.5, 100.0
            reroute_009.width, reroute_009.height = 14.5, 100.0
            reroute_010.width, reroute_010.height = 14.5, 100.0
            reroute_011.width, reroute_011.height = 14.5, 100.0
            group_input_013.width, group_input_013.height = 140.0, 100.0
            group_input_014.width, group_input_014.height = 140.0, 100.0
            group_input_015.width, group_input_015.height = 140.0, 100.0
            group_input_016.width, group_input_016.height = 140.0, 100.0
            group_input_017.width, group_input_017.height = 140.0, 100.0
            group_004.width, group_004.height = 140.0, 100.0
            group_input_018.width, group_input_018.height = 140.0, 100.0
            object_info_003.width, object_info_003.height = 140.0, 100.0
            raycast_001.width, raycast_001.height = 150.0, 100.0
            named_attribute.width, named_attribute.height = 140.0, 100.0
            transform_geometry_001_1.width, transform_geometry_001_1.height = 140.0, 100.0
            store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
            set_material.width, set_material.height = 140.0, 100.0
            group_input_020.width, group_input_020.height = 140.0, 100.0
            group_input_019.width, group_input_019.height = 140.0, 100.0
            switch_1.width, switch_1.height = 140.0, 100.0
            group_input_021.width, group_input_021.height = 140.0, 100.0
            mesh_to_volume_2.width, mesh_to_volume_2.height = 200.0, 100.0
            volume_to_mesh_2.width, volume_to_mesh_2.height = 170.0, 100.0
            math_2.width, math_2.height = 140.0, 100.0
            object_info_004.width, object_info_004.height = 140.0, 100.0
            reroute_012.width, reroute_012.height = 14.5, 100.0
            reroute_013.width, reroute_013.height = 14.5, 100.0
            reroute_014.width, reroute_014.height = 14.5, 100.0

            #initialize archsv links
            #random_value.Value -> delete_geometry_2.Selection
            archsv.links.new(random_value.outputs[3], delete_geometry_2.inputs[1])
            #group_001_1.Inverted -> group_002.Geometry
            archsv.links.new(group_001_1.outputs[0], group_002.inputs[0])
            #group_001_1.Inverted -> switch_002.False
            archsv.links.new(group_001_1.outputs[0], switch_002.inputs[1])
            #separate_xyz_1.Z -> compare_1.A
            archsv.links.new(separate_xyz_1.outputs[2], compare_1.inputs[0])
            #position_2.Position -> separate_xyz_1.Vector
            archsv.links.new(position_2.outputs[0], separate_xyz_1.inputs[0])
            #group_002.Geometry -> switch_002.True
            archsv.links.new(group_002.outputs[0], switch_002.inputs[2])
            #group_input_003.End Resolution -> merge_by_distance_1.Distance
            archsv.links.new(group_input_003.outputs[18], merge_by_distance_1.inputs[2])
            #separate_xyz_1.Z -> compare_001.A
            archsv.links.new(separate_xyz_1.outputs[2], compare_001.inputs[0])
            #group_input_004.Base? -> group_002.Base/Top
            archsv.links.new(group_input_004.outputs[7], group_002.inputs[1])
            #group_input_004.Slope Fac -> group_002.Nor Var
            archsv.links.new(group_input_004.outputs[8], group_002.inputs[2])
            #group_input_004.Smo It -> group_002.Iterations
            archsv.links.new(group_input_004.outputs[9], group_002.inputs[3])
            #merge_by_distance_1.Geometry -> delete_geometry_001_1.Geometry
            archsv.links.new(merge_by_distance_1.outputs[0], delete_geometry_001_1.inputs[0])
            #compare_002_2.Result -> delete_geometry_001_1.Selection
            archsv.links.new(compare_002_2.outputs[0], delete_geometry_001_1.inputs[1])
            #vertex_neighbors.Vertex Count -> compare_002_2.A
            archsv.links.new(vertex_neighbors.outputs[0], compare_002_2.inputs[2])
            #compare_001.Result -> boolean_math_2.Boolean
            archsv.links.new(compare_001.outputs[0], boolean_math_2.inputs[1])
            #compare_1.Result -> boolean_math_2.Boolean
            archsv.links.new(compare_1.outputs[0], boolean_math_2.inputs[0])
            #scale_elements_1.Geometry -> raycast_1.Target Geometry
            archsv.links.new(scale_elements_1.outputs[0], raycast_1.inputs[0])
            #transform_geometry_1.Geometry -> scale_elements_1.Geometry
            archsv.links.new(transform_geometry_1.outputs[0], scale_elements_1.inputs[0])
            #raycast_1.Is Hit -> boolean_math_001_1.Boolean
            archsv.links.new(raycast_1.outputs[0], boolean_math_001_1.inputs[0])
            #boolean_math_001_1.Boolean -> delete_geometry_002.Selection
            archsv.links.new(boolean_math_001_1.outputs[0], delete_geometry_002.inputs[1])
            #mesh_to_points.Points -> delete_geometry_2.Geometry
            archsv.links.new(mesh_to_points.outputs[0], delete_geometry_2.inputs[0])
            #delete_geometry_2.Geometry -> group_001_1.Geometry
            archsv.links.new(delete_geometry_2.outputs[0], group_001_1.inputs[0])
            #group_input_002.Simplify -> switch_003.Switch
            archsv.links.new(group_input_002.outputs[17], switch_003.inputs[0])
            #reroute.Output -> group_001_1.Socket
            archsv.links.new(reroute.outputs[0], group_001_1.inputs[1])
            #reroute_001.Output -> reroute.Input
            archsv.links.new(reroute_001.outputs[0], reroute.inputs[0])
            #reroute_001.Output -> mesh_to_points.Mesh
            archsv.links.new(reroute_001.outputs[0], mesh_to_points.inputs[0])
            #transform_geometry_1.Geometry -> reroute_006.Input
            archsv.links.new(transform_geometry_1.outputs[0], reroute_006.inputs[0])
            #reroute_006.Output -> join_geometry.Geometry
            archsv.links.new(reroute_006.outputs[0], join_geometry.inputs[0])
            #reroute_006.Output -> reroute_007.Input
            archsv.links.new(reroute_006.outputs[0], reroute_007.inputs[0])
            #delete_geometry_002.Geometry -> reroute_008.Input
            archsv.links.new(delete_geometry_002.outputs[0], reroute_008.inputs[0])
            #convex_hull.Convex Hull -> group_001_1.Attribute
            archsv.links.new(convex_hull.outputs[0], group_001_1.inputs[2])
            #object_info_001.Geometry -> join_geometry_001.Geometry
            archsv.links.new(object_info_001.outputs[4], join_geometry_001.inputs[0])
            #group_003.Polygon -> transform_geometry_1.Geometry
            archsv.links.new(group_003.outputs[0], transform_geometry_1.inputs[0])
            #join_geometry_001.Geometry -> reroute_001.Input
            archsv.links.new(join_geometry_001.outputs[0], reroute_001.inputs[0])
            #object_info_002.Geometry -> attribute_statistic_3.Geometry
            archsv.links.new(object_info_002.outputs[4], attribute_statistic_3.inputs[0])
            #compare_003_1.Result -> switch_005.Switch
            archsv.links.new(compare_003_1.outputs[0], switch_005.inputs[0])
            #delete_geometry_002.Geometry -> switch_005.True
            archsv.links.new(delete_geometry_002.outputs[0], switch_005.inputs[2])
            #join_geometry.Geometry -> switch_005.False
            archsv.links.new(join_geometry.outputs[0], switch_005.inputs[1])
            #switch_005.Output -> group_1.Geometry
            archsv.links.new(switch_005.outputs[0], group_1.inputs[0])
            #index_1.Index -> attribute_statistic_3.Attribute
            archsv.links.new(index_1.outputs[0], attribute_statistic_3.inputs[2])
            #attribute_statistic_3.Max -> compare_003_1.A
            archsv.links.new(attribute_statistic_3.outputs[4], compare_003_1.inputs[0])
            #group_1.SphereVolume -> menu_switch.SphereVolume
            archsv.links.new(group_1.outputs[0], menu_switch.inputs[4])
            #boolean_math_2.Boolean -> boolean_math_002_1.Boolean
            archsv.links.new(boolean_math_2.outputs[0], boolean_math_002_1.inputs[0])
            #boolean_math_002_1.Boolean -> delete_geometry_003.Selection
            archsv.links.new(boolean_math_002_1.outputs[0], delete_geometry_003.inputs[1])
            #switch_002.Output -> delete_geometry_003.Geometry
            archsv.links.new(switch_002.outputs[0], delete_geometry_003.inputs[0])
            #delete_geometry_003.Geometry -> group_003.Geometry
            archsv.links.new(delete_geometry_003.outputs[0], group_003.inputs[0])
            #group_1.VoxelVolume -> menu_switch.VoxelVolume
            archsv.links.new(group_1.outputs[1], menu_switch.inputs[5])
            #switch_002.Output -> reroute_002.Input
            archsv.links.new(switch_002.outputs[0], reroute_002.inputs[0])
            #reroute_002.Output -> menu_switch.PreViz Mesh
            archsv.links.new(reroute_002.outputs[0], menu_switch.inputs[1])
            #group_input_005.Volume Sub Level -> group_1.Voxel Amount
            archsv.links.new(group_input_005.outputs[16], group_1.inputs[4])
            #group_input_006.Volume Resolution -> group_1.Sphere Volume Iterations
            archsv.links.new(group_input_006.outputs[15], group_1.inputs[3])
            #group_input_007.Output -> menu_switch.Menu
            archsv.links.new(group_input_007.outputs[14], menu_switch.inputs[0])
            #group_input_008.Guide Mesh -> object_info_002.Object
            archsv.links.new(group_input_008.outputs[2], object_info_002.inputs[0])
            #group_input_001_2.Geometry -> convex_hull.Geometry
            archsv.links.new(group_input_001_2.outputs[0], convex_hull.inputs[0])
            #group_input_009.Decimation Ration -> random_value.Probability
            archsv.links.new(group_input_009.outputs[3], random_value.inputs[6])
            #group_input_010.Base Mesh -> object_info.Object
            archsv.links.new(group_input_010.outputs[1], object_info.inputs[0])
            #group_input_011.Guide Mesh -> object_info_001.Object
            archsv.links.new(group_input_011.outputs[2], object_info_001.inputs[0])
            #group_input_9.Poly Res -> group_003.Count
            archsv.links.new(group_input_9.outputs[12], group_003.inputs[1])
            #group_input_012.Translation -> transform_geometry_1.Translation
            archsv.links.new(group_input_012.outputs[13], transform_geometry_1.inputs[1])
            #group_003.Polyline -> reroute_003.Input
            archsv.links.new(group_003.outputs[1], reroute_003.inputs[0])
            #reroute_003.Output -> reroute_005.Input
            archsv.links.new(reroute_003.outputs[0], reroute_005.inputs[0])
            #reroute_007.Output -> reroute_009.Input
            archsv.links.new(reroute_007.outputs[0], reroute_009.inputs[0])
            #reroute_009.Output -> menu_switch.Polygon
            archsv.links.new(reroute_009.outputs[0], menu_switch.inputs[3])
            #reroute_005.Output -> reroute_010.Input
            archsv.links.new(reroute_005.outputs[0], reroute_010.inputs[0])
            #reroute_010.Output -> reroute_011.Input
            archsv.links.new(reroute_010.outputs[0], reroute_011.inputs[0])
            #reroute_011.Output -> menu_switch.Polyline
            archsv.links.new(reroute_011.outputs[0], menu_switch.inputs[2])
            #group_input_013.XY Variance -> group_001_1.XY
            archsv.links.new(group_input_013.outputs[4], group_001_1.inputs[3])
            #group_input_014.Z Variance -> group_001_1.Z
            archsv.links.new(group_input_014.outputs[5], group_001_1.inputs[4])
            #group_input_015.Max Z -> compare_1.B
            archsv.links.new(group_input_015.outputs[10], compare_1.inputs[1])
            #group_input_016.Min Z -> compare_001.B
            archsv.links.new(group_input_016.outputs[11], compare_001.inputs[1])
            #group_input_017.Slope Segmentation -> switch_002.Switch
            archsv.links.new(group_input_017.outputs[6], switch_002.inputs[0])
            #delete_geometry_001_1.Geometry -> switch_003.True
            archsv.links.new(delete_geometry_001_1.outputs[0], switch_003.inputs[2])
            #group_004.ContextMesh -> menu_switch.RefinedMesh
            archsv.links.new(group_004.outputs[0], menu_switch.inputs[6])
            #reroute_010.Output -> group_004.Polyline
            archsv.links.new(reroute_010.outputs[0], group_004.inputs[1])
            #group_004.LeftoverMesh -> menu_switch.LeftoverMesh
            archsv.links.new(group_004.outputs[1], menu_switch.inputs[7])
            #group_input_018.Cutter Scale -> group_004.Scale
            archsv.links.new(group_input_018.outputs[19], group_004.inputs[2])
            #transform_geometry_001_1.Geometry -> raycast_001.Target Geometry
            archsv.links.new(transform_geometry_001_1.outputs[0], raycast_001.inputs[0])
            #named_attribute.Attribute -> raycast_001.Attribute
            archsv.links.new(named_attribute.outputs[0], raycast_001.inputs[1])
            #raycast_001.Attribute -> store_named_attribute.Value
            archsv.links.new(raycast_001.outputs[4], store_named_attribute.inputs[3])
            #store_named_attribute.Geometry -> set_material.Geometry
            archsv.links.new(store_named_attribute.outputs[0], set_material.inputs[0])
            #switch_003.Output -> store_named_attribute.Geometry
            archsv.links.new(switch_003.outputs[0], store_named_attribute.inputs[0])
            #object_info_003.Geometry -> transform_geometry_001_1.Geometry
            archsv.links.new(object_info_003.outputs[4], transform_geometry_001_1.inputs[0])
            #group_input_020.Guide Mesh -> object_info_003.Object
            archsv.links.new(group_input_020.outputs[2], object_info_003.inputs[0])
            #group_input_019.Material -> set_material.Material
            archsv.links.new(group_input_019.outputs[21], set_material.inputs[2])
            #switch_003.Output -> switch_1.False
            archsv.links.new(switch_003.outputs[0], switch_1.inputs[1])
            #group_input_021.Texture Mesh? -> switch_1.Switch
            archsv.links.new(group_input_021.outputs[20], switch_1.inputs[0])
            #switch_1.Output -> mesh_to_volume_2.Mesh
            archsv.links.new(switch_1.outputs[0], mesh_to_volume_2.inputs[0])
            #mesh_to_volume_2.Volume -> volume_to_mesh_2.Volume
            archsv.links.new(mesh_to_volume_2.outputs[0], volume_to_mesh_2.inputs[0])
            #volume_to_mesh_2.Mesh -> group_output_9.Geometry
            archsv.links.new(volume_to_mesh_2.outputs[0], group_output_9.inputs[0])
            #menu_switch.Output -> switch_003.False
            archsv.links.new(menu_switch.outputs[0], switch_003.inputs[1])
            #set_material.Geometry -> switch_1.True
            archsv.links.new(set_material.outputs[0], switch_1.inputs[2])
            #math_2.Value -> raycast_001.Ray Length
            archsv.links.new(math_2.outputs[0], raycast_001.inputs[4])
            #group_input_020.Texture extension -> math_2.Value
            archsv.links.new(group_input_020.outputs[22], math_2.inputs[0])
            #group_input_008.Base Mesh -> object_info_004.Object
            archsv.links.new(group_input_008.outputs[1], object_info_004.inputs[0])
            #object_info_004.Geometry -> reroute_012.Input
            archsv.links.new(object_info_004.outputs[4], reroute_012.inputs[0])
            #reroute_012.Output -> reroute_013.Input
            archsv.links.new(reroute_012.outputs[0], reroute_013.inputs[0])
            #reroute_013.Output -> group_004.Mesh
            archsv.links.new(reroute_013.outputs[0], group_004.inputs[0])
            #reroute_002.Output -> reroute_014.Input
            archsv.links.new(reroute_002.outputs[0], reroute_014.inputs[0])
            #reroute_004.Output -> delete_geometry_002.Geometry
            archsv.links.new(reroute_004.outputs[0], delete_geometry_002.inputs[0])
            #reroute.Output -> reroute_004.Input
            archsv.links.new(reroute.outputs[0], reroute_004.inputs[0])
            #menu_switch.Output -> merge_by_distance_1.Geometry
            archsv.links.new(menu_switch.outputs[0], merge_by_distance_1.inputs[0])
            #object_info.Geometry -> join_geometry_001.Geometry
            archsv.links.new(object_info.outputs[4], join_geometry_001.inputs[0])
            #reroute_008.Output -> join_geometry.Geometry
            archsv.links.new(reroute_008.outputs[0], join_geometry.inputs[0])
            output_socket_1.default_value = 'PreViz Mesh'
            return archsv

        archsv = archsv_node_group()

        name = bpy.context.object.name
        obj = bpy.data.objects[name]
        mod = obj.modifiers.new(name = "ArchSV", type = 'NODES')
        mod.node_group = archsv
        return {'FINISHED'}

def menu_func(self, context):
    self.layout.operator(ArchSV.bl_idname)

def register():
    bpy.utils.register_class(ArchSV)
    bpy.utils.register_class(ArchSV_PT_Panel)
    bpy.utils.register_class(ARCHSV_OT_AddCurveDraw)
    bpy.utils.register_class(ARCHSV_OT_WaitForCurveVertices)
    bpy.types.NODE_MT_add.append(menu_func)

def unregister():
    bpy.utils.unregister_class(ArchSV)
    bpy.utils.unregister_class(ArchSV_PT_Panel)
    bpy.utils.unregister_class(ARCHSV_OT_AddCurveDraw)
    bpy.utils.unregister_class(ARCHSV_OT_WaitForCurveVertices)
    bpy.types.NODE_MT_add.remove(menu_func)

if __name__ == "__main__":
    register()
